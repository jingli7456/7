import os
import sys
import re
import json
import hashlib
from datetime import datetime
import pandas as pd
import numpy as np
import jieba
import random
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import normalize
from sklearn.utils import resample
from scipy import stats
from gensim.models import Doc2Vec
from gensim.models.doc2vec import TaggedDocument
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.font_manager as fm
from collections import Counter
from typing import Dict, List, Tuple, Set, Optional
import warnings
warnings.filterwarnings('ignore')

# ==================== 全局设置 ====================

CENTRAL_PATH = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/Central_data_69'
LOCAL_PATH = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/Local_data_193'
RMRB_PATH = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/rmrb-master'
OUTPUT_DIR = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/results'

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==================== 【修改1】加载新旧文件名映射表 ====================
import json

HASH_MAPPING_CENTRAL = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/hash_mapping_central.json'
HASH_MAPPING_LOCAL   = '/Users/swnn/Desktop/Youth_Sports_central_local_data/Youth_Sports_central_local_data/hash_mapping_local.json'

try:
    with open(HASH_MAPPING_CENTRAL, 'r', encoding='utf-8') as f:
        NEW_TO_OLD_FILE_CENTRAL = json.load(f)
    print(f"[OK] 中央新旧文件名映射表: {len(NEW_TO_OLD_FILE_CENTRAL)} 条")
except FileNotFoundError:
    NEW_TO_OLD_FILE_CENTRAL = {}
    print(f"[!] 未找到中央映射表 {HASH_MAPPING_CENTRAL}")

try:
    with open(HASH_MAPPING_LOCAL, 'r', encoding='utf-8') as f:
        NEW_TO_OLD_FILE_LOCAL = json.load(f)
    print(f"[OK] 地方新旧文件名映射表: {len(NEW_TO_OLD_FILE_LOCAL)} 条")
except FileNotFoundError:
    NEW_TO_OLD_FILE_LOCAL = {}
    print(f"[!] 未找到地方映射表 {HASH_MAPPING_LOCAL}")

NEW_TO_OLD_FILE = {}
NEW_TO_OLD_FILE.update(NEW_TO_OLD_FILE_CENTRAL)
NEW_TO_OLD_FILE.update(NEW_TO_OLD_FILE_LOCAL)
print(f"[OK] 合并映射表: {len(NEW_TO_OLD_FILE)} 条")
# ==================== 【修改1 结束】 ====================

# 设置matplotlib后端和基本参数
matplotlib.use('Agg')

# 设置中文字体 - 修复乱码问题
def setup_chinese_font():
    """【修改】图表现为纯英文，不再需要中文字体"""
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial', 'Helvetica']
    plt.rcParams['axes.unicode_minus'] = False
    return 'DejaVu Sans'

# 初始化中文字体
setup_chinese_font()

plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")
sns.set_palette("husl")

# ==================== 英文映射表（新增） ====================

REGION_EN = {
    '东部': 'East',
    '中部': 'Central',
    '西部': 'West',
    '东北': 'Northeast',
    '中央': 'Central',
    '未知': 'Unknown'
}

PROVINCE_PINYIN = {
    'beijing': '北京', 'tianjin': '天津', 'hebei': '河北', 'shanxi': '山西',
    'shaanxi': '陕西',
    'neimenggu': '内蒙古',           # ← 匹配 034-2015-Neimenggu.txt
    'inner_mongolia': '内蒙古',      # 兼容 Inner_Mongolia 形式
    'inner mongolia': '内蒙古',       # 兼容 InnerMongolia 形式
    'liaoning': '辽宁', 'jilin': '吉林', 'heilongjiang': '黑龙江',
    'shanghai': '上海', 'jiangsu': '江苏', 'zhejiang': '浙江', 'anhui': '安徽',
    'fujian': '福建', 'jiangxi': '江西', 'shandong': '山东', 'henan': '河南',
    'hubei': '湖北', 'hunan': '湖南', 'guangdong': '广东', 'guangxi': '广西',
    'hainan': '海南', 'chongqing': '重庆', 'sichuan': '四川', 'guizhou': '贵州',
    'yunnan': '云南', 'xizang': '西藏', 'tibet': '西藏',
    'gansu': '甘肃', 'qinghai': '青海', 'ningxia': '宁夏', 'xinjiang': '新疆',
}

GRADE_EN = {
    '优秀': 'Excellent',
    '良好': 'Good',
    '可接受': 'Acceptable',
    '不良': 'Poor',
    '未知': 'Unknown'
}


RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

# 分层抽样配置
STRATIFIED_SAMPLE_CONFIG = {
    'total_sample': 8,
    'region_ratio': {'东北': 1, '东部': 2, '中部': 2, '西部': 3},
    'periods': ['十二五', '十三五', '十四五']
}

# 人民日报语料配置 - 【修改】采样数量从500增加到5000
PEOPLE_DAILY_CONFIG = {
    'max_articles': 5000,      # 最大采样文章数（从500增加到5000）
    'keywords_top_n': 500,      # 提取的高频关键词数量
}

# Doc2Vec模型参数
# 【修改】workers 从 4 改为 1，确保可复现性
DOC2VEC_PARAMS = {
    'dm': 1,
    'window': 5,
    'min_count': 1,
    'vector_size': 200,
    'epochs': 30,
    'workers': 1,              # 【修改】强制单线程，确保可复现
    'seed': RANDOM_SEED
}

# 31个省份列表
ALL_PROVINCES = [
    '北京', '天津', '河北', '山西', '内蒙古', '辽宁', '吉林', '黑龙江',
    '上海', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南',
    '湖北', '湖南', '广东', '广西', '海南', '重庆', '四川', '贵州',
    '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆'
]

# ==================== 省份中文 → 英文映射 ====================
PROVINCE_EN = {
    '北京': 'Beijing', '天津': 'Tianjin', '河北': 'Hebei', '山西': 'Shanxi',
    '内蒙古': 'Inner Mongolia', '辽宁': 'Liaoning', '吉林': 'Jilin', '黑龙江': 'Heilongjiang',
    '上海': 'Shanghai', '江苏': 'Jiangsu', '浙江': 'Zhejiang', '安徽': 'Anhui',
    '福建': 'Fujian', '江西': 'Jiangxi', '山东': 'Shandong', '河南': 'Henan',
    '湖北': 'Hubei', '湖南': 'Hunan', '广东': 'Guangdong', '广西': 'Guangxi',
    '海南': 'Hainan', '重庆': 'Chongqing', '四川': 'Sichuan', '贵州': 'Guizhou',
    '云南': 'Yunnan', '西藏': 'Xizang', '陕西': 'Shaanxi', '甘肃': 'Gansu',
    '青海': 'Qinghai', '宁夏': 'Ningxia', '新疆': 'Xinjiang'
}


# ==================== 省份拼音 → 中文映射 ====================
# 注意：shanxi=山西，shaanxi=陕西，务必区分
# 注意：内蒙古的文件名形如 179-2025-Inner_Mongolia.txt
#       匹配时统一小写，故键写成 'inner_mongolia'
PROVINCE_PINYIN = {
    'beijing': '北京', 'tianjin': '天津', 'hebei': '河北', 'shanxi': '山西',
    'shaanxi': '陕西',
    'inner_mongolia': '内蒙古',      # 匹配 179-2025-Inner_Mongolia.txt
    'innermongolia': '内蒙古',       # 兼容无下划线形式
    'neimenggu': '内蒙古',           # 兼容拼音形式
    'liaoning': '辽宁', 'jilin': '吉林', 'heilongjiang': '黑龙江',
    'shanghai': '上海', 'jiangsu': '江苏', 'zhejiang': '浙江', 'anhui': '安徽',
    'fujian': '福建', 'jiangxi': '江西', 'shandong': '山东', 'henan': '河南',
    'hubei': '湖北', 'hunan': '湖南', 'guangdong': '广东', 'guangxi': '广西',
    'hainan': '海南', 'chongqing': '重庆', 'sichuan': '四川', 'guizhou': '贵州',
    'yunnan': '云南', 'xizang': '西藏', 'tibet': '西藏',
    'gansu': '甘肃', 'qinghai': '青海', 'ningxia': '宁夏', 'xinjiang': '新疆',
}


# ==================== 省份-区域映射 ====================
PROVINCE_REGION_MAP = {
    '北京': '东部', '天津': '东部', '河北': '东部', 
    '上海': '东部', '江苏': '东部', '浙江': '东部', 
    '福建': '东部', '山东': '东部', '广东': '东部', '海南': '东部',
    '山西': '中部', '安徽': '中部', '江西': '中部', 
    '河南': '中部', '湖北': '中部', '湖南': '中部',
    '内蒙古': '西部', '广西': '西部', '重庆': '西部', 
    '四川': '西部', '贵州': '西部', '云南': '西部', 
    '西藏': '西部', '陕西': '西部', '甘肃': '西部', 
    '青海': '西部', '宁夏': '西部', '新疆': '西部',
    '辽宁': '东北', '吉林': '东北', '黑龙江': '东北'
}

# ==================== 青少年体育PMC指标体系（9个一级指标，删除X10） ====================
# 一级指标配置（9个，等权重）
PRIMARY_INDICATORS = {
    "X1": {"name": "政策级别", "description": "政策的发布层级与权威性"},
    "X2": {"name": "政策执行性", "description": "政策的可操作性与执行基础"},
    "X3": {"name": "政策性质", "description": "政策的性质与导向特征"},
    "X4": {"name": "政策目标", "description": "政策对青少年体育训练的核心目标"},
    "X5": {"name": "政策时效", "description": "政策的有效时间范围"},
    "X6": {"name": "政策对象", "description": "政策覆盖的群体与组织"},
    "X7": {"name": "政策评价", "description": "政策自身的评价与反馈机制"},
    "X8": {"name": "政策视角", "description": "政策设计的出发点与价值导向"},
    "X9": {"name": "政策内容要素", "description": "政策涵盖的具体内容领域"},
    # X10 已删除（央地一致性）
}

PRIMARY_KEYS = ["X1", "X2", "X3", "X4", "X5", "X6", "X7", "X8", "X9"]

# ==================== 二级指标配置（34个，删除X10相关） ====================
def get_secondary_config() -> Dict:
    """二级指标配置，包含关键词和参考文献（34个，删除X10）"""
    return {
        # X1 政策级别（2个）
        "X1-1": {"name": "国家级", "primary": "X1", "keywords": ["国家", "全国", "中央", "国家级", "国务院"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X1-2": {"name": "省市级", "primary": "X1", "keywords": ["省", "市", "省级", "市级", "地方"], "reference": "鲁志威等（2024），程美超等（2025）"},
        
        # X2 政策执行性（4个）
        "X2-1": {"name": "执行措施", "primary": "X2", "keywords": ["措施", "办法", "方案", "机制", "制度", "落实"], "reference": "程美超等（2025），宣江鑫等（2024）"},
        "X2-2": {"name": "保障机制", "primary": "X2", "keywords": ["保障", "确保", "保证", "提供", "支持"], "reference": "程美超等（2025），宣江鑫等（2024）"},
        "X2-3": {"name": "组织协调", "primary": "X2", "keywords": ["组织", "协调", "统筹", "协同", "联动"], "reference": "程美超等（2025），宣江鑫等（2024）"},
        "X2-4": {"name": "资源投入", "primary": "X2", "keywords": ["投入", "资金", "财政", "经费", "拨款"], "reference": "程美超等（2025），宣江鑫等（2024）"},
        
        # X3 政策性质（4个）
        "X3-1": {"name": "引导性", "primary": "X3", "keywords": ["引导", "鼓励", "支持", "推动", "促进"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X3-2": {"name": "规范性", "primary": "X3", "keywords": ["规范", "标准", "规定", "要求", "制度"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X3-3": {"name": "激励性", "primary": "X3", "keywords": ["激励", "奖励", "表彰", "补贴", "奖金"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X3-4": {"name": "约束性", "primary": "X3", "keywords": ["问责", "处罚", "禁止", "不得", "严禁", "督查"], "reference": "鲁志威等（2024），程美超等（2025）"},
        
        # X4 政策目标（4个）
        "X4-1": {"name": "体质健康", "primary": "X4", "keywords": ["健康", "体质", "体能", "身体素质"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X4-2": {"name": "人才培养", "primary": "X4", "keywords": ["人才", "培养", "后备", "选拔", "梯队"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X4-3": {"name": "参与普及", "primary": "X4", "keywords": ["参与", "普及", "覆盖", "推广", "大众"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X4-4": {"name": "安全保障", "primary": "X4", "keywords": ["安全", "风险", "预防", "防护", "保险"], "reference": "鲁志威等（2024），程美超等（2025）"},
        
        # X5 政策时效（3个）
        "X5-1": {"name": "长期", "primary": "X5", "keywords": ["长期", "持续", "长效", "长远", "常态化"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X5-2": {"name": "中期", "primary": "X5", "keywords": ["十四五", "五年", "规划", "阶段"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X5-3": {"name": "短期", "primary": "X5", "keywords": ["年度", "今年", "当前", "近期"], "reference": "鲁志威等（2024），程美超等（2025）"},
        
        # X6 政策对象（5个）
        "X6-1": {"name": "青少年", "primary": "X6", "keywords": ["青少年", "少年", "青年", "未成年人"], "reference": "鲁志威等（2024），程美超等（2025）"},
        "X6-2": {"name": "学生群体", "primary": "X6", "keywords": ["学生", "学校", "校园", "在校生"], "reference": "程美超等（2025）"},
        "X6-3": {"name": "儿童", "primary": "X6", "keywords": ["儿童", "小学", "少儿", "幼儿"], "reference": "程美超等（2025）"},
        "X6-4": {"name": "专业训练", "primary": "X6", "keywords": ["体校", "俱乐部", "专业队", "训练基地"], "reference": "程美超等（2025）"},
        "X6-5": {"name": "特殊群体", "primary": "X6", "keywords": ["特殊", "残疾", "留守", "农村", "贫困"], "reference": "程美超等（2025）"},
        
        # X7 政策评价（3个）
        "X7-1": {"name": "目标明确", "primary": "X7", "keywords": ["目标", "指标", "量化", "完成", "实现"], "reference": "程美超等（2025），鲁志威等（2024）"},
        "X7-2": {"name": "方案科学", "primary": "X7", "keywords": ["科学", "合理", "可行", "设计"], "reference": "程美超等（2025），鲁志威等（2024）"},
        "X7-3": {"name": "监督评估", "primary": "X7", "keywords": ["监督", "评估", "考核", "检查", "督导"], "reference": "程美超等（2025），鲁志威等（2024）"},
        
        # X8 政策视角（4个）
        "X8-1": {"name": "国家战略", "primary": "X8", "keywords": ["体育强国", "强国", "国际", "奥运"], "reference": "宣江鑫等（2024），程美超等（2025）"},
        "X8-2": {"name": "全面发展", "primary": "X8", "keywords": ["全面", "素质", "个性化"], "reference": "宣江鑫等（2024），程美超等（2025）"},
        "X8-3": {"name": "体教融合", "primary": "X8", "keywords": ["体教融合", "体教结合", "体育教育"], "reference": "宣江鑫等（2024），程美超等（2025）"},
        "X8-4": {"name": "社会协同", "primary": "X8", "keywords": ["社会", "协同", "融合", "合作", "市场"], "reference": "宣江鑫等（2024），程美超等（2025）"},
        
        # X9 政策内容要素（5个）
        "X9-1": {"name": "训练内容", "primary": "X9", "keywords": ["训练", "训练计划", "训练方法"], "reference": "鲁志威等（2024）"},
        "X9-2": {"name": "教练师资", "primary": "X9", "keywords": ["教练", "师资", "教师", "培训"], "reference": "鲁志威等（2024）"},
        "X9-3": {"name": "场地设施", "primary": "X9", "keywords": ["场地", "设施", "场馆", "器材"], "reference": "鲁志威等（2024）"},
        "X9-4": {"name": "竞赛体系", "primary": "X9", "keywords": ["竞赛", "比赛", "联赛", "赛事"], "reference": "鲁志威等（2024）"},
        "X9-5": {"name": "时间安排", "primary": "X9", "keywords": ["时间", "课时", "时长", "频率"], "reference": "鲁志威等（2024）"},
    }


def get_pmc_indicator_system() -> pd.DataFrame:
    """生成完整的PMC指标体系表"""
    config = get_secondary_config()
    data = []
    for sid, cfg in config.items():
        pid = cfg["primary"]
        data.append({
            "一级指标代码": pid,
            "一级指标名称": PRIMARY_INDICATORS[pid]["name"],
            "一级指标描述": PRIMARY_INDICATORS[pid]["description"],
            "二级指标代码": sid,
            "二级指标名称": cfg["name"],
            "评价标准": "关键词命中率（分段评分法-平衡版）",
            "关键词": "、".join(cfg["keywords"]),
            "参考文献": cfg.get("reference", "")
        })
    df = pd.DataFrame(data)
    return df


# ==================== 等权重提供器 ====================

class EqualWeightProvider:
    """等权重提供器 - 替代德尔菲法"""
    
    def __init__(self):
        self.n_indicators = len(PRIMARY_KEYS)  # 9个指标
        self.equal_weight = 1.0 / self.n_indicators
        
    def get_weights(self) -> Dict[str, float]:
        return {pid: self.equal_weight for pid in PRIMARY_KEYS}
    
    def get_weights_dataframe(self) -> pd.DataFrame:
        weights = self.get_weights()
        data = [{
            "指标代码": k,
            "指标名称": PRIMARY_INDICATORS[k]["name"],
            "权重": round(v, 4),
            "权重百分比": f"{v*100:.1f}%"
        } for k, v in weights.items()]
        df = pd.DataFrame(data)
        return df.sort_values("权重", ascending=False).reset_index(drop=True)
    
    def get_statistics(self) -> pd.DataFrame:
        data = [{
            "指标代码": k,
            "指标名称": PRIMARY_INDICATORS[k]["name"],
            "均值": 1.0,
            "标准差": 0.0,
            "变异系数": 0.0,
            "共识等级": "等权重（无德尔菲）"
        } for k in PRIMARY_KEYS]
        return pd.DataFrame(data)
    
    def get_consensus_report(self) -> str:
        report = f"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                        等权重配置说明                                        ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║  权重分配方式：等权重                                                       ║
║  一级指标数量：{self.n_indicators} 个（已删除X10央地一致性）                                      ║
║  每个指标权重：{self.equal_weight:.4f}                                                       ║
║  权重百分比：{self.equal_weight*100:.1f}%                                                    ║
║                                                                             ║
║  说明：本系统已移除德尔菲法，采用等权重方案，所有一级指标权重相同。          ║
╚═══════════════════════════════════════════════════════════════════════════════╝
        """
        return report
    
    def get_expert_count(self) -> int:
        return 0


# ==================== 辅助函数 ====================

def load_stopwords() -> Set[str]:
    """加载统一的中文停用词"""
    stopwords = {
        '的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上',
        '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这',
        '那', '但', '可以', '我们', '他们', '她们', '它们', '这个', '那个', '这些', '那些','担任',
        '与', '或', '并', '及', '为', '对', '从', '由', '以', '被', '把', '让', '给', '向',
        '能', '会', '可', '以', '得', '等', '还', '就', '才', '都', '又', '也', '而', '且',
        '如果', '那么', '但是', '虽然', '然而', '否则', '因此', '所以', '因为', '由于', '开放',
        '以及', '及其', '等等', '例如', '比如', '包括', '具有', '进行', '产生', '发生', '相关',
        '成为', '作为', '关于', '对于', '基于', '通过', '根据', '按照', '采用', '应当', '各省',
        '提出', '认为', '指出', '表明', '显示', '发现', '提供', '形成', '实现', '工作', '各地',
        '活动', '支持', '单位', '单项', '推动', '吉林省','建立', '学科', '认定', '积极','指导',
        '北京市', '运动', '体育总局', '教育部', '体育局', '法宝','申报', '负责', '鼓励', '上报',
        '行政部门', '国家体育总局', '各盟', '确定', '自治区', '因素', '建设', '中等', '设置','教育厅',
        '部门','国家', '自查', '艺术', '项目', '情况', '要求', '或者', '江苏省','更加','加大','促进',
        '发展','学生', '学校', '完善', '美育', '兼职教师', '选聘', '办法', '教师队伍','文化','管理',
        '推进','提升', '教育', '健康', '使用', '分钟','风险', '安全', '成绩','等级','标准','指标',
        '六年级','小学', '提高', '结果', '人员', '规定','融合', '全面', '纳入','资金','共建','各区',
        '区县','等级','培养','服务','各地', '美育', '资助','经费', '实施','标准','教育','学生','附表',
        '项目','全国','计划','跳绳','建设',  '检查', '活动','各级', '以上','取得','天津市','体教',
        '社会','疫情','普通','评定','良好', '优秀', '认真', '主体', '中心','加强','形势','三年级',
        '水平','制定','有关','其他','不得','登记卡', '二年级', '文件', '规范性','各市','参加','司法案例',
        '条例','发布','命名','课余','代表队','督导','训练', '专项经费', '青少','年度','中央','培训',
        '专项','预算','云南省','地区','质量','分配','重点', '布局', '相应','机构','机制','制度','卫生',
        '保证','学习','做好','体系','人民政府','责任','财政厅', '目标', '高等院校','绩效','群众','坚持',
        '卫生','确保','综合','地方','不少','安徽省教育厅','条件', '对象', '选项','中华人民共和国','得分',
        '签字','五年级','四年级','厘米','进一步','创建活动', '重大', '分为','市级','解决','必须','下发',
        '省政府','我省','长跑','基本','一级','评估', '评价', '集中','及时','安排','切实','称号','星级',
        '设区','三是','二是','一是', '印发', '符合','防近','体卫艺司','一年级','控制','通知','县级',
        '强化','消毒','汇总','内容', '重要', '报表','分别','落实','中小学校','体育运动','知识','志愿',
        '人才','市教委','教师','上海市', '各校', '能力','全省','依法','政府','抽查','省级​','以下',
        '明确​','直辖市','全民','后备','五个', '山东省','认真贯彻','附件','结束','教育局​','行政','公布',
         }
    return stopwords


def bootstrap_ci(data: np.ndarray, statistic: callable = np.mean, 
                 n_bootstrap: int = 1000, ci_level: float = 0.95) -> Tuple[float, float, float]:
    np.random.seed(RANDOM_SEED)
    bootstrap_stats = []
    n = len(data)
    
    for i in range(n_bootstrap):
        sample = resample(data, n_samples=n, random_state=RANDOM_SEED + i)
        bootstrap_stats.append(statistic(sample))
    
    original_stat = statistic(data)
    alpha = (1 - ci_level) / 2
    ci_lower = np.percentile(bootstrap_stats, alpha * 100)
    ci_upper = np.percentile(bootstrap_stats, (1 - alpha) * 100)
    
    return original_stat, ci_lower, ci_upper


def cohens_d(group1: np.ndarray, group2: np.ndarray) -> float:
    n1, n2 = len(group1), len(group2)
    var1, var2 = np.var(group1, ddof=1), np.var(group2, ddof=1)
    pooled_std = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
    if pooled_std == 0:
        return 0.0
    return abs(np.mean(group1) - np.mean(group2)) / pooled_std


def read_file_with_encoding(file_path):
    encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030', 'utf-16', 'latin-1', 'cp936', 'big5']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            if content and len(content.strip()) > 0:
                return content, encoding
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception:
            continue
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        if content and len(content.strip()) > 0:
            return content, 'utf-8(ignore)'
    except Exception:
        pass
    
    return None, None

def extract_province_from_filename(filename: str) -> str:
    """
    提取省份（中文优先，拼音兜底）
    - 旧数据文件名含中文省份（"北京市"、"湖北省"）
    - 新数据文件名含拼音省份（"Beijing"、"Hubei"）
    - 两种数据都能正确识别
    """
    name = filename.replace('.txt', '')

    # 1. 中文匹配（旧数据）
    province_map = {
        '北京': '北京', '天津': '天津', '上海': '上海', '重庆': '重庆',
        '河北': '河北', '山西': '山西', '辽宁': '辽宁', '吉林': '吉林',
        '黑龙江': '黑龙江', '江苏': '江苏', '浙江': '浙江', '安徽': '安徽',
        '福建': '福建', '江西': '江西', '山东': '山东', '河南': '河南',
        '湖北': '湖北', '湖南': '湖南', '广东': '广东', '海南': '海南',
        '四川': '四川', '贵州': '贵州', '云南': '云南', '陕西': '陕西',
        '甘肃': '甘肃', '青海': '青海', '台湾': '台湾',
        '内蒙古': '内蒙古', '广西': '广西', '西藏': '西藏',
        '宁夏': '宁夏', '新疆': '新疆'
    }
    for province, full_name in province_map.items():
        if province in name:
            return full_name

    # 2. 拼音匹配（新数据）—— 长拼音优先，防止 shanxi 吃掉 shaanxi
    name_lower = name.lower()
    for py in sorted(PROVINCE_PINYIN.keys(), key=len, reverse=True):
        if py in name_lower:
            return PROVINCE_PINYIN[py]

    return "未知"


def extract_period_from_filename(filename: str, content: str = None) -> str:
    """从文件名或正文提取时期"""
    name = filename.replace('.txt', '')

    if '十二五' in name:
        return '十二五'
    elif '十三五' in name:
        return '十三五'
    elif '十四五' in name:
        return '十四五'
    elif '2021' in name or '2022' in name or '2023' in name or '2024' in name or '2025' in name:
        return '十四五'
    elif '2016' in name or '2017' in name or '2018' in name or '2019' in name or '2020' in name:
        return '十三五'
    elif '2011' in name or '2012' in name or '2013' in name or '2014' in name or '2015' in name:
        return '十二五'

    # 正文兜底
    if content:
        head = content[:1000]
        year_match = re.search(r'(20\d{2})', head)
        if year_match:
            y = int(year_match.group(1))
            if y >= 2021:
                return '十四五'
            elif y >= 2016:
                return '十三五'
            elif y >= 2011:
                return '十二五'

    return '未知'
# ==================== 【修改2】从旧文件名识别政策类型 ====================
def extract_policy_type_from_old_filename(old_filename: str) -> str:
    """
    完全复刻旧代码的政策类型识别逻辑
    只认中文关键词，与旧代码 100% 一致
    """
    name = old_filename.replace('.txt', '')
    if '规划' in name:
        return '发展规划'
    elif '实施意见' in name or '意见' in name:
        return '实施意见'
    elif '实施方案' in name or '方案' in name:
        return '实施方案'
    elif '行动计划' in name or '计划' in name:
        return '行动计划'
    elif '通知' in name:
        return '通知'
    elif '指导意见' in name:
        return '指导意见'
    elif '决定' in name:
        return '决定'
    else:
        return '其他'
# ==================== 【修改2 结束】 ====================

# ==================== 政策类型识别（原版，供兜底） ====================
def extract_policy_type_from_filename(filename: str, content: str = None) -> str:
    """
    从文件名 + 正文识别政策类型
    用于 get_policy_type_for_new_file 兜底
    """
    name = filename.replace('.txt', '')

    type_map = [
        ('发展规划', ['发展规划', '规划']),
        ('指导意见', ['指导意见']),
        ('实施意见', ['实施意见']),
        ('实施方案', ['实施方案', '工作方案']),
        ('行动计划', ['行动计划']),
        ('决定',     ['决定']),
        ('通知',     ['通知']),
        ('意见',     ['意见']),
        ('方案',     ['方案']),
    ]

    # 1. 文件名匹配
    for ptype, kws in type_map:
        for kw in kws:
            if kw in name:
                return ptype

    # 2. 正文兜底
    if content:
        head = content[:500]
        for ptype, kws in type_map:
            for kw in kws:
                if kw in head:
                    return ptype

    return '其他'
# ==================== 结束 ====================

# ==================== 【修改3】统一政策类型识别入口 ====================
def get_policy_type_for_new_file(new_filename: str, content: str = None, is_central: bool = False) -> str:
    """
    优先用旧数据文件名识别政策类型（保证与旧代码一致）
    is_central=True 时查中央映射表，否则查地方映射表
    """
    mapping = NEW_TO_OLD_FILE_CENTRAL if is_central else NEW_TO_OLD_FILE_LOCAL
    if new_filename in mapping:
        old_filename = mapping[new_filename]
        return extract_policy_type_from_old_filename(old_filename)
    return extract_policy_type_from_filename(new_filename, content)

# ==================== Doc2Vec相关函数 ====================

def cut_sentences(text):
    sentences = re.split(r'[。！？；\n]', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) >= 5]
    return sentences


def read_policy_to_sentences(folder_path, policy_type, stopwords):
    all_sentences = []
    policy_count = 0
    
    print(f"\nReading {policy_type} policy files...")
    
    if not os.path.exists(folder_path):
        print(f"Error: Folder does not exist!")
        return all_sentences, 0
    

    files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    files = sort_files_by_old_order(files)   # 【修改9】按旧数据顺序排序
    print(f"Found {len(files)} txt files")
    
    for filename in files:
        file_path = os.path.join(folder_path, filename)
        content, encoding = read_file_with_encoding(file_path)
        
        if not content:
            print(f"  ✗ Failed (encoding issue): {filename}")
            continue
        
        if len(content.strip()) < 50:
            continue
        
        sentences = cut_sentences(content)
        
        for sent_idx, sent in enumerate(sentences):
            words = jieba.lcut(sent)
            words = [w for w in words if w not in stopwords and len(w) > 1]
            if len(words) < 2:
                continue
            
            all_sentences.append({
                'policy_id': filename.replace('.txt', ''),
                'policy_type': policy_type,
                'sentence_idx': sent_idx,
                'original_sentence': sent,
                'tokenized_words': words,
                'tokenized_text': ' '.join(words)
            })
        
        policy_count += 1
        if policy_count % 20 == 0:
            print(f"  Processed {policy_count}/{len(files)} files")
    
    print(f"Completed: {policy_count} policy files, {len(all_sentences)} valid sentences")
    return all_sentences, policy_count


def train_doc2vec_model(sentences_data, vector_size=100, epochs=20):
    print(f"\nTraining Doc2Vec model...")
    print(f"  Vector dimension: {vector_size}")
    print(f"  Epochs: {epochs}")
    print(f"  Sentences count: {len(sentences_data)}")
    
    # 固定随机种子
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    random.shuffle(sentences_data)
    
    documents = []
    for sent in sentences_data:
        tag = f"{sent['policy_type']}_{sent['policy_id']}_{sent['sentence_idx']}"
        sent['unique_id'] = tag
        documents.append(TaggedDocument(words=sent['tokenized_words'], tags=[tag]))
    
    model = Doc2Vec(
        documents=documents,
        vector_size=vector_size,
        window=5,
        min_count=2,
        epochs=epochs,
        dm=1,
        workers=4,
        seed=RANDOM_SEED
    )
    
    vectors = {}
    for doc in documents:
        vectors[doc.tags[0]] = model.dv[doc.tags[0]]
    
    print(f"Doc2Vec model training completed")
    return model, vectors, documents


def calculate_similarity_with_random_sampling(central_sentences, local_sentences, vectors, max_samples=5000):
    print(f"\nCalculating Central-Local policy similarity with random sampling...")
    print(f"  Original Central sentences: {len(central_sentences)}")
    print(f"  Original Local sentences: {len(local_sentences)}")
    
    random.seed(RANDOM_SEED)
    
    central_sampled = central_sentences
    local_sampled = local_sentences
    
    if len(central_sentences) > max_samples:
        central_sampled = random.sample(central_sentences, max_samples)
        print(f"  Sampled Central sentences: {len(central_sampled)} (random sampling)")
    
    if len(local_sentences) > max_samples:
        local_sampled = random.sample(local_sentences, max_samples)
        print(f"  Sampled Local sentences: {len(local_sampled)} (random sampling)")
    
    central_vectors = []
    for sent in central_sampled:
        vec = vectors.get(sent['unique_id'])
        if vec is not None:
            central_vectors.append(vec)
    
    local_vectors = []
    for sent in local_sampled:
        vec = vectors.get(sent['unique_id'])
        if vec is not None:
            local_vectors.append(vec)
    
    if len(central_vectors) == 0 or len(local_vectors) == 0:
        print("Error: No valid vectors found")
        return None
    
    central_vectors = np.array(central_vectors)
    local_vectors = np.array(local_vectors)
    
    similarity_matrix = cosine_similarity(local_vectors, central_vectors)
    max_similarities = similarity_matrix.max(axis=1)
    
    stats = {
        'central_sentence_count': len(central_sampled),
        'local_sentence_count': len(local_sampled),
        'mean_similarity': np.mean(max_similarities),
        'median_similarity': np.median(max_similarities),
        'std_similarity': np.std(max_similarities),
        'min_similarity': np.min(max_similarities),
        'max_similarity': np.max(max_similarities),
        'similarities_distribution': max_similarities.tolist(),
    }
    
    print(f"\nSimilarity Statistics:")
    print(f"  Mean: {stats['mean_similarity']:.4f}")
    print(f"  Median: {stats['median_similarity']:.4f}")
    print(f"  Std Dev: {stats['std_similarity']:.4f}")
    print(f"  Min: {stats['min_similarity']:.4f}")
    print(f"  Max: {stats['max_similarity']:.4f}")
    
    return stats


# ==================== 分层抽样模块 ====================

def load_policy_data_for_sampling(central_path: str, local_path: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    print("\n" + "=" * 60)
    print("加载政策数据用于分层抽样")
    print("=" * 60)

    local_records = []
    central_records = []

    # ==================== [1] 加载地方政策 ====================
    print(f"\n[1] 加载地方政策 ({local_path})")
    if os.path.exists(local_path):
        files = [f for f in os.listdir(local_path) if f.endswith('.txt')]
        files.sort()
        print(f"  发现 {len(files)} 个文件")

        for i, filename in enumerate(files):
            province = extract_province_from_filename(filename)
            region = PROVINCE_REGION_MAP.get(province, '未知')
            period = extract_period_from_filename(filename)

            # 读取正文，用于识别政策类型
            file_path = os.path.join(local_path, filename)
            content, _ = read_file_with_encoding(file_path)

            # 【修改4】优先用旧文件名识别政策类型
            policy_type = get_policy_type_for_new_file(filename, content, is_central=False)

            type_score_map = {
                '发展规划': 5,
                '实施意见': 4,
                '实施方案': 3,
                '行动计划': 3,
                '通知': 2,
                '指导意见': 4,
                '决定': 3,
                '其他': 2
            }
            represent_score = type_score_map.get(policy_type, 2)

            local_records.append({
                '文件名称': filename,
                '旧文件名称': NEW_TO_OLD_FILE_LOCAL.get(filename, filename),
                '发布省份': province,
                '区域': region,
                '所属时期': period,
                '政策类型': policy_type,
                '代表性评分': round(represent_score, 2),
                '文件路径': file_path
            })

            if (i + 1) % 50 == 0:
                print(f"  已处理 {i+1}/{len(files)} 个文件")

        print(f"  成功加载 {len(local_records)} 条地方政策记录")
    else:
        print(f"  ❌ 路径不存在: {local_path}")

    # ==================== [2] 加载中央政策 ====================
    print(f"\n[2] 加载中央政策 ({central_path})")
    if os.path.exists(central_path):
        files = [f for f in os.listdir(central_path) if f.endswith('.txt')]
        files.sort()
        print(f"  发现 {len(files)} 个文件")

        for filename in files:
            period = extract_period_from_filename(filename)

            file_path = os.path.join(central_path, filename)
            content, _ = read_file_with_encoding(file_path)

            # 【修改5】中央政策也用映射表识别政策类型
            policy_type = get_policy_type_for_new_file(filename, content, is_central=True)

            publish_year = "未知"
            if content:
                year_match = re.search(r'(20\d{2})', content[:500])
                if year_match:
                    publish_year = year_match.group(1)

            central_records.append({
                '文件名称': filename,
                '旧文件名称': NEW_TO_OLD_FILE_CENTRAL.get(filename, ''),
                '发布机构': '国家体育总局/教育部等',
                '发布时间': publish_year,
                '政策类型': policy_type,
                '所属时期': period,
                '文件路径': file_path
            })

        print(f"  成功加载 {len(central_records)} 条中央政策记录")
    else:
        print(f"  ❌ 路径不存在: {central_path}")

    # ==================== [3] 汇总 ====================
    local_df = pd.DataFrame(local_records)
    central_df = pd.DataFrame(central_records)

    print(f"\n[3] 数据加载完成:")
    print(f"  地方政策: {len(local_df)} 份")
    print(f"  中央政策: {len(central_df)} 份")

    return local_df, central_df
# ==================== 【层一新增】抽样前预计算 PMC 与等级 ====================

def precompute_pmc_for_sampling(
    local_df: pd.DataFrame,
    secondary: Dict,
    weights: Dict[str, float]
) -> pd.DataFrame:
    """
    为抽样候选政策预计算 PMC 和等级，用于在抽样阶段排除"不良"等级。
    
    参数：
        local_df: load_policy_data_for_sampling 返回的地方政策 DataFrame
        secondary: 二级指标配置（calculate_match_rates 的第二个返回值）
        weights: 一级指标权重（EqualWeightProvider.get_weights()）
    
    返回：
        增加了 '_PMC' 和 '_等级' 两列的 DataFrame
    """
    print("\n" + "=" * 80)
    print("【层一】抽样前预计算 PMC 与等级（用于排除'不良'）")
    print("=" * 80)

    pmc_list = []
    grade_list = []
    total = len(local_df)

    for i, (idx, row) in enumerate(local_df.iterrows()):
        fp = row.get('文件路径', '')
        pmc = None
        grade = '未知'

        if os.path.exists(fp):
            content, _ = read_file_with_encoding(fp)
            if content:
                pmc = calc_single_pmc_score(content, secondary, weights)
                grade = get_pmc_grade(pmc)

        pmc_list.append(pmc)
        grade_list.append(grade)

        if (i + 1) % 50 == 0:
            print(f"   已计算 {i+1}/{total} 份")

    local_df = local_df.copy()
    local_df['_PMC'] = pmc_list
    local_df['_等级'] = grade_list

    print(f"\n   预计算完成，等级分布：")
    grade_counts = local_df['_等级'].value_counts().to_dict()
    for g, c in grade_counts.items():
        print(f"      {g}: {c} 份")

    return local_df

# ================================================================

def stratified_sample_policies(
    df: pd.DataFrame,
    total_sample: int = 8,
    region_ratio: Dict[str, int] = None,
    periods: List[str] = None
) -> pd.DataFrame:
    """
    分层抽样（代表性评分优先 + 区域配额 + 三时期强制覆盖）：

    - 硬约束1：每个省份只保留代表性评分最高的1份政策
    - 硬约束2：区域配额 东北1、东部2、中部2、西部3
    - 硬约束3：十二五、十三五、十四五 各至少 1 份（强制）
    - 排序依据：代表性评分降序 + 排序键（旧文件名）升序
    """
    if region_ratio is None:
        region_ratio = {'东北': 1, '东部': 2, '中部': 2, '西部': 3}
    if periods is None:
        periods = ['十二五', '十三五', '十四五']

    # 加"排序键"列（用旧文件名，保证与旧代码排序一致）
    df = df.copy()
    df['_排序键'] = df['文件名称'].map(lambda x: NEW_TO_OLD_FILE_LOCAL.get(x, x))

    print("\n" + "=" * 80)
    print("分层抽样：代表性评分优先 + 区域配额 + 三时期强制覆盖")
    print("=" * 80)
    print(f"目标样本量: {total_sample}")
    print(f"区域配额: {region_ratio}")
    print(f"时期强制覆盖: {periods}")

    # ========== Step 1: 省份去重（保留代表性评分最高的 1 份） ==========
    print("\n[Step 1] 省份去重（每省保留代表性评分最高的1份）")
    df_dedup = (
        df.sort_values(['代表性评分', '_排序键'], ascending=[False, True])
          .drop_duplicates(subset=['发布省份'], keep='first')
          .reset_index(drop=True)
    )
    df_dedup['区域'] = df_dedup['发布省份'].map(
        lambda x: PROVINCE_REGION_MAP.get(x, '未知')
    )
    print(f"  原始: {len(df)} 份 → 去重后: {len(df_dedup)} 份")

    selected_rows = []
    used_provinces = set()
    region_count = {r: 0 for r in region_ratio}

    # ========== Step 2: 时期强制配额（每期至少1份，不超区域配额） ==========
    print("\n[Step 2] 时期强制配额（每期至少 1 份，不超区域配额）")
    for period in periods:
        period_df = df_dedup[
            (df_dedup['所属时期'] == period) &
            (~df_dedup['发布省份'].isin(used_provinces))
        ].copy()

        if len(period_df) == 0:
            print(f"  [!!] {period}: 无可选政策（数据中缺失）")
            continue

        # 标记区域是否已满
        period_df['_region_full'] = period_df['区域'].apply(
            lambda r: region_count.get(r, 0) >= region_ratio.get(r, 999)
        )

        # 区域未满的优先，再按代表性评分降序、排序键升序
        period_df = period_df.sort_values(
            by=['_region_full', '代表性评分', '_排序键'],
            ascending=[True, False, True]
        )

        row = period_df.iloc[0]
        selected_rows.append(row)
        used_provinces.add(row['发布省份'])
        region_count[row['区域']] = region_count.get(row['区域'], 0) + 1

        print(f"  [OK] {period}: {row['发布省份']} ({row['区域']}) "
              f"| 评分={row['代表性评分']:.1f} | {row['政策类型']}")

    print(f"\n  时期配额后区域分布: {region_count}")

    # ========== Step 3: 区域配额补足 ==========
    print("\n[Step 3] 区域配额补足")
    for region, target in region_ratio.items():
        need = target - region_count[region]
        if need <= 0:
            print(f"  [--] {region}: 已满足 ({region_count[region]}/{target})")
            continue

        region_df = df_dedup[
            (df_dedup['区域'] == region) &
            (~df_dedup['发布省份'].isin(used_provinces))
        ].sort_values(['代表性评分', '_排序键'], ascending=[False, True])

        picked = 0
        for _, row in region_df.iterrows():
            if picked >= need:
                break
            selected_rows.append(row)
            used_provinces.add(row['发布省份'])
            region_count[region] += 1
            picked += 1
            print(f"  [OK] {region}: {row['发布省份']} "
                  f"| {row['所属时期']} | 评分={row['代表性评分']:.1f}")

        if picked < need:
            print(f"  [!] {region}: 只能补 {picked}/{need} 份")

    # ========== Step 4: 总数不足时从全局补 ==========
    if len(selected_rows) < total_sample:
        print(f"\n[Step 4] 总数不足（{len(selected_rows)}/{total_sample}），从全局补")
        remaining = df_dedup[~df_dedup['发布省份'].isin(used_provinces)] \
            .sort_values(['代表性评分', '_排序键'], ascending=[False, True])
        for _, row in remaining.iterrows():
            if len(selected_rows) >= total_sample:
                break
            selected_rows.append(row)
            used_provinces.add(row['发布省份'])
            print(f"  [OK] 补充: {row['发布省份']} | {row['所属时期']} "
                  f"| 评分={row['代表性评分']:.1f}")

    # ========== Step 5: 汇总 ==========
    result = pd.DataFrame(selected_rows).reset_index(drop=True)
    result = result.drop(columns=['_region_full'], errors='ignore')

    print("\n" + "=" * 80)
    print("抽样结果验证（三时期强制覆盖）")
    print("=" * 80)
    print(f"最终样本量: {len(result)}")

    print("\n【时期分布】")
    for period in periods:
        cnt = len(result[result['所属时期'] == period])
        status = "[OK]" if cnt > 0 else "[!!]"
        print(f"  {status} {period}: {cnt} 份")

    print("\n【区域分布】")
    for region in ['东北', '东部', '中部', '西部']:
        cnt = len(result[result['区域'] == region])
        target = region_ratio.get(region, 0)
        status = "[OK]" if cnt == target else "[!]"
        print(f"  {status} {region}: {cnt} 份 (目标 {target})")

    # ========== Step 6: 时期强制兜底 ==========
    present_periods = set(result['所属时期'].unique())
    missing_periods = [p for p in periods if p not in present_periods]

    if missing_periods:
        print(f"\n[Step 6] 时期强制兜底：缺失 {missing_periods}")
        print(f"         策略：替换'时期重复'的省份，必要时打破区域配额")

        for p in missing_periods:
            fallback_pool = df_dedup[
                (df_dedup['所属时期'] == p) &
                (~df_dedup['发布省份'].isin(used_provinces))
            ].sort_values(['代表性评分', '_排序键'], ascending=[False, True])

            if len(fallback_pool) == 0:
                print(f"  [X] {p}: 全局候选中也无该时期政策，无法补足")
                continue

            period_counts = result['所属时期'].value_counts()
            replace_candidates = result[
                result['所属时期'].apply(lambda x: period_counts.get(x, 0) > 1)
            ].sort_values(['代表性评分', '_排序键'], ascending=[True, True])

            if len(replace_candidates) == 0:
                replace_candidates = result.sort_values(
                    ['代表性评分', '_排序键'], ascending=[True, True]
                )

            old_row = replace_candidates.iloc[0]
            new_row = fallback_pool.iloc[0]

            print(f"  [补] {old_row['发布省份']}({old_row['区域']}, {old_row['所属时期']}) "
                  f"→ {new_row['发布省份']}({new_row['区域']}, {new_row['所属时期']})")

            result = result[result['发布省份'] != old_row['发布省份']]
            result = pd.concat([result, pd.DataFrame([new_row])], ignore_index=True)
            used_provinces.discard(old_row['发布省份'])
            used_provinces.add(new_row['发布省份'])

        present_periods = set(result['所属时期'].unique())
        missing_after = [p for p in periods if p not in present_periods]
        if missing_after:
            print(f"\n  [!!] 兜底后仍缺失: {missing_after}")
        else:
            print(f"\n  [OK] 兜底后三时期全覆盖")
    else:
        print(f"\n[Step 6] [OK] 三时期已全覆盖，无需兜底")

    # 重新排序
    result = result.reset_index(drop=True)

    print("\n【选中省份列表】")
    for _, row in result.iterrows():
        print(f"  {row['发布省份']:4} | {row['区域']:2} | {row['所属时期']:4} "
              f"| 评分={row['代表性评分']:.1f} | {row['政策类型']}")

    # 清理临时列
    result = result.drop(columns=['_排序键'], errors='ignore')

    return result


def select_central_policy_sampling(central_df: pd.DataFrame) -> pd.Series:
    print("\n选择中央政策样本...")
    
    if len(central_df) == 0:
        print("  错误: 无中央政策数据")
        return pd.Series()
    
    def calculate_central_score(row):
        score = 0
        if row['所属时期'] == '十四五':
            score += 3
        elif row['所属时期'] == '十三五':
            score += 2
        elif row['所属时期'] == '十二五':
            score += 1

        # 【修改】优先用映射表识别政策类型（会走旧文件名，与旧代码一致）
        file_path = row.get('文件路径', '')
        content = None
        if file_path and os.path.exists(file_path):
            content, _ = read_file_with_encoding(file_path)

        policy_type = get_policy_type_for_new_file(
            row['文件名称'], content, is_central=True
        )

        if policy_type in ['发展规划', '指导意见']:
            score += 2
        elif policy_type in ['实施意见', '实施方案']:
            score += 1

        # 用旧文件名判断"体育"关键词（新文件名不含"体育"二字）
        old_name = NEW_TO_OLD_FILE_CENTRAL.get(row['文件名称'], row['文件名称'])
        if '青少年体育' in old_name or '体育' in old_name:
            score += 1

        return score  
    
    central_df_copy = central_df.copy()
    central_df_copy['综合评分'] = central_df_copy.apply(calculate_central_score, axis=1)
    central_df_sorted = central_df_copy.sort_values('综合评分', ascending=False)
    selected = central_df_sorted.iloc[0]
    print(f"  选中: {selected['文件名称']}")
    print(f"  综合评分: {selected['综合评分']}")
    
    return selected


def run_stratified_sampling(
    central_path: str = CENTRAL_PATH,
    local_path: str = LOCAL_PATH,
    total_sample: int = 8,
    region_ratio: Dict[str, int] = None,
    periods: List[str] = None,
    secondary: Dict = None,
    weights: Dict[str, float] = None
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series]:
    """
    分层抽样主流程：
    - 层一：预计算 PMC 并保留全部等级（含"不良"），不做剔除
    - 层二：由 main() 中的等级修补函数负责（必覆盖 优秀/良好/可接受，不良）
    - 时期 + 区域 双层约束
    """
    if region_ratio is None:
        region_ratio = STRATIFIED_SAMPLE_CONFIG['region_ratio']
    if periods is None:
        periods = STRATIFIED_SAMPLE_CONFIG['periods']

    print("\n" + "=" * 80)
    print("分层抽样模块（层一：保留全部等级 + 时期/区域双层约束）")
    print("=" * 80)
    print(f"目标样本量: {total_sample} 项")
    print(f"区域比例: {region_ratio}")
    print(f"时期覆盖: {periods}")
    print(f"说明: 层一不剔除任何等级（含'不良'），等级修补由层二在表11 生成前处理")

    local_df, central_df = load_policy_data_for_sampling(central_path, local_path)

    if len(local_df) == 0:
        print("[X] 错误: 未加载到任何地方政策数据")
        return pd.DataFrame(), pd.DataFrame(), pd.Series()

    print("\n[4] 原始数据分布:")
    print("   - 区域分布:")
    print(local_df['区域'].value_counts().to_string())
    print("\n   - 时期分布:")
    print(local_df['所属时期'].value_counts().to_string())

    # ==================== 【层一】预计算 PMC（保留全部等级，含不良） ====================
    if secondary is not None and weights is not None:
        local_df = precompute_pmc_for_sampling(local_df, secondary, weights)

        total = len(local_df)
        grade_dist = local_df['_等级'].value_counts().to_dict()

        print(f"\n【层一】抽样候选池保留全部等级（含'不良'）")
        print(f"   候选池总数: {total} 份")
        print(f"   等级分布: {grade_dist}")
    else:
        print("\n[!] 未传入 secondary/weights，跳过 PMC 预计算")
        print("    请在 main() 中先把 calculate_match_rates / weights 提前")
    # ====================================================================

    # ==================== 抽样（时期 + 区域双层约束） ====================
    sampled_local = stratified_sample_policies(
        local_df, total_sample, region_ratio, periods
    )
    central_selected = select_central_policy_sampling(central_df)

    print("\n" + "=" * 60)
    print("抽样结果")
    print("=" * 60)

    print(f"\n【省级政策样本 ({len(sampled_local)}项)】")
    print("-" * 80)
    display_cols = ['文件名称', '发布省份', '区域', '所属时期', '政策类型', '代表性评分']
    available_cols = [c for c in display_cols if c in sampled_local.columns]
    if len(available_cols) > 0:
        print(sampled_local[available_cols].to_string(index=False))

    print("\n【区域分布验证】")
    if len(sampled_local) > 0:
        print(sampled_local['区域'].value_counts().sort_index().to_string())

    print("\n【时期分布验证】")
    if len(sampled_local) > 0:
        print(sampled_local['所属时期'].value_counts().sort_index().to_string())

    # ==================== 【层一】抽样后等级分布（仅展示，不判断） ====================
    if '_等级' in sampled_local.columns:
        print("\n【抽样后等级分布（层二修补前的参考，不做判断）】")
        print(sampled_local['_等级'].value_counts().to_string())
        print("   说明：层一保留全部等级，不良是否保留由层二等级修补决定")
    # ====================================================================

    print("\n" + "-" * 80)
    if not central_selected.empty:
        print(f"\n【中央政策样本 (1项)】")
        print("-" * 80)
        print(f"  文件名称: {central_selected['文件名称']}")
        print(f"  所属时期: {central_selected['所属时期']}")
        print(f"  发布机构: {central_selected.get('发布机构', '未知')}")
        print(f"  发布时间: {central_selected.get('发布时间', '未知')}")

    print("\n[5] 保存抽样结果...")
    if len(sampled_local) > 0:
        # 【按需求】去掉"代表性评分"和"_region_full"，保留"政策类型"
        save_local = sampled_local.drop(
            columns=['代表性评分', '_region_full'],
            errors='ignore'
        )
        save_local.to_csv(
            os.path.join(OUTPUT_DIR, '省级政策抽样结果.csv'),
            index=False, encoding='utf-8-sig'
        )
        print(f"   [OK] 省级政策抽样结果: "
              f"{os.path.join(OUTPUT_DIR, '省级政策抽样结果.csv')}")

    if not central_selected.empty:
        # 【按需求】去掉"综合评分"
        save_central = pd.DataFrame([central_selected]).drop(
            columns=['综合评分'],
            errors='ignore'
        )
        save_central.to_csv(
            os.path.join(OUTPUT_DIR, '中央政策抽样结果.csv'),
            index=False, encoding='utf-8-sig'
        )
        print(f"   [OK] 中央政策抽样结果: "
              f"{os.path.join(OUTPUT_DIR, '中央政策抽样结果.csv')}")

    return sampled_local, local_df, central_selected


# ==================== 模块一：LDA主题模型 ====================
# ==================== 【修改7】按旧数据顺序排序文件 ====================
def sort_files_by_old_order(files: List[str]) -> List[str]:
    """
    按旧数据文件名的字典序排列新数据文件，保证 LDA / Doc2Vec 输入顺序与旧代码一致
    如果映射表为空，则退化为普通字典序
    """
    if not NEW_TO_OLD_FILE:
        return sorted(files)
    
    # 建立旧文件名 → 排序索引
    old_files_sorted = sorted(NEW_TO_OLD_FILE.values())
    old_file_to_index = {f: i for i, f in enumerate(old_files_sorted)}
    
    # 按旧数据顺序重排
    return sorted(
        files,
        key=lambda x: old_file_to_index.get(NEW_TO_OLD_FILE.get(x, ''), 999999)
    )
# ==================== 【修改7 结束】 ====================



def read_text_files(folder_path, folder_name):
    documents = []
    file_names = []
    
    print(f"\nReading folder: {folder_name}")
    
    if not os.path.exists(folder_path):
        print(f"Error: Folder does not exist!")
        return documents, file_names
    

    files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    files = sort_files_by_old_order(files)   # 【修改8】按旧数据顺序排序
    print(f"Found {len(files)} txt files")

    
    for filename in files:
        file_path = os.path.join(folder_path, filename)
        content, encoding = read_file_with_encoding(file_path)
        
        if content and len(content.strip()) > 50:
            documents.append(content)
            file_names.append(filename)
            print(f"  ✓ Read: {filename} (encoding: {encoding})")
        elif content:
            print(f"  ✗ Skipped (too short): {filename}")
        else:
            print(f"  ✗ Failed (encoding issue): {filename}")
    
    print(f"Successfully read {len(documents)} documents")
    return documents, file_names


def preprocess_text(text, stopwords):
    text = re.sub(r'[^\u4e00-\u9fa5]', ' ', text)
    words = jieba.cut(text)
    words = [w.strip() for w in words if len(w.strip()) > 1 and w not in stopwords]
    return ' '.join(words)


def generate_topic_name(topic_words):
    if len(topic_words) >= 3:
        name = '、'.join(topic_words[:3])
        if len(name) > 20:
            name = name[:20] + "..."
        return name
    return '、'.join(topic_words) if topic_words else "Unnamed Topic"


def analyze_topics_with_perplexity(documents, folder_name, stopwords):
    print(f"\n{'=' * 60}")
    print(f"Analyzing {folder_name} (Perplexity for optimal topic number)")
    print(f"{'=' * 60}")
    
    if len(documents) < 3:
        print(f"Insufficient documents ({len(documents)} < 3)")
        return None
    
    print("Preprocessing text...")
    processed = []
    for doc in documents:
        processed_doc = preprocess_text(doc, stopwords)
        if processed_doc:
            processed.append(processed_doc)
    
    print(f"Valid documents after preprocessing: {len(processed)}")
    
    if len(processed) < 3:
        print("Insufficient valid documents")
        return None
    
    print("Creating document-term matrix...")
    vectorizer = CountVectorizer(max_df=0.95, min_df=2, max_features=2000)
    dtm = vectorizer.fit_transform(processed)
    feature_names = vectorizer.get_feature_names_out()
    print(f"Matrix shape: {dtm.shape}")
    
    word_freq = np.array(dtm.sum(axis=0)).flatten()
    words = vectorizer.get_feature_names_out()
    freq_df = pd.DataFrame({'word': words, 'freq': word_freq})
    freq_df = freq_df.sort_values('freq', ascending=False)
    freq_output = os.path.join(OUTPUT_DIR, f'word_freq_{folder_name}.csv')
    freq_df.to_csv(freq_output, index=False, encoding='utf-8-sig')
    print(f"Word frequency saved: {freq_output}")
    
    print("Calculating TF-IDF...")
    tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2, max_features=2000)
    tfidf_matrix = tfidf_vectorizer.fit_transform(processed)
    tfidf_sums = np.array(tfidf_matrix.sum(axis=0)).flatten()
    tfidf_words = tfidf_vectorizer.get_feature_names_out()
    tfidf_df = pd.DataFrame({'word': tfidf_words, 'tfidf': tfidf_sums})
    tfidf_df = tfidf_df.sort_values('tfidf', ascending=False)
    tfidf_output = os.path.join(OUTPUT_DIR, f'tfidf_{folder_name}.csv')
    tfidf_df.head(20).to_csv(tfidf_output, index=False, encoding='utf-8-sig')
    
    print("\nCalculating perplexity for different topic numbers...")
    
    max_topics = min(10, len(processed) - 1)
    if max_topics < 3:
        max_topics = 3
    topic_range = range(3, max_topics + 1)
    
    print(f"Topic range: 3 to {max_topics}")
    
    results = []
    perplexities = []
    
    for k in topic_range:
        print(f"  Computing k={k}...", end=' ')
        try:
            lda = LatentDirichletAllocation(
                n_components=k,
                random_state=RANDOM_SEED,
                max_iter=100,
                learning_method='online',
                n_jobs=1
            )
            lda.fit(dtm)
            
            perplexity = lda.perplexity(dtm)
            log_likelihood = lda.score(dtm)
            
            results.append({
                'k': k,
                'perplexity': perplexity,
                'log_likelihood': log_likelihood
            })
            perplexities.append(perplexity)
            
            print(f"Perplexity={perplexity:.2f}")
            
        except Exception as e:
            print(f"Failed: {e}")
    
    if not results:
        print("Cannot compute any topic model")
        return None
    
    results_df = pd.DataFrame(results)
    results_output = os.path.join(OUTPUT_DIR, f'perplexity_results_{folder_name}.csv')
    results_df.to_csv(results_output, index=False, encoding='utf-8-sig')
    
    print(f"\n{'=' * 70}")
    print(f"{folder_name} Topic Model Perplexity Results")
    print(f"{'=' * 70}")
    print(f"{'Topics':<8} {'Perplexity':<15} {'Log Likelihood':<15}")
    print(f"{'-' * 70}")
    for r in results:
        print(f"{r['k']:<8} {r['perplexity']:<15.2f} {r['log_likelihood']:<15.2f}")
    
    best_k = list(topic_range)[np.argmin(perplexities)]
    print(f"\nOptimal topic number based on perplexity: {best_k}")
    
    plt.figure(figsize=(10, 6))
    plt.plot(list(topic_range), perplexities, 'bo-', linewidth=2, markersize=8)
    plt.xlabel('Number of Topics (k)', fontsize=12, fontweight='bold')
    plt.ylabel('Perplexity', fontsize=12, fontweight='bold')

    # 【修改】去掉图表标题
    # plt.title(...)  # 已移除

    plt.grid(True, alpha=0.3)

    best_idx = list(topic_range).index(best_k)
    plt.plot(best_k, perplexities[best_idx], 'r*', markersize=15, label=f'Best: k={best_k}')
    plt.legend(fontsize=11, loc='upper right')  
    
    y_min = min(perplexities) * 0.95
    y_max = max(perplexities) * 1.05
    plt.ylim(y_min, y_max)
    
    plt.tight_layout()
    perplexity_output = os.path.join(OUTPUT_DIR, f'perplexity_{folder_name}.png')
    plt.savefig(perplexity_output, dpi=1000, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"Perplexity curve saved: {perplexity_output}")
    
    print(f"\nTraining final model with k={best_k}...")
    final_lda = LatentDirichletAllocation(
        n_components=best_k,
        random_state=RANDOM_SEED,
        max_iter=200,
        learning_method='online'
    )
    doc_topic = final_lda.fit_transform(dtm)
    
    # 【修改】主题关键词改为Top 8
    print(f"\n{'=' * 60}")
    print(f"{folder_name} - Topic Keywords (Top 8)")
    print(f"{'=' * 60}")
    
    topic_words_list = []
    topic_names = []
    for topic_idx, topic in enumerate(final_lda.components_):
        # 【修改】取Top 8关键词（原来是Top 15）
        top_words_idx = topic.argsort()[:-9:-1]  # 取Top 8
        top_words = [feature_names[i] for i in top_words_idx]
        topic_words_list.append(top_words)
        
        topic_name = generate_topic_name(top_words)
        topic_names.append(topic_name)
        
        print(f"\nTopic {topic_idx + 1}: {topic_name}")
        # 【修改】显示Top 8关键词
        print(f"  Keywords: {', '.join(top_words[:8])}")
    
    max_len = max(len(words) for words in topic_words_list)
    topic_df = pd.DataFrame({
        f'Topic{i+1}_{topic_names[i]}': words + ['']*(max_len - len(words)) 
        for i, words in enumerate(topic_words_list)
    })
    topics_output = os.path.join(OUTPUT_DIR, f'topics_{folder_name}.csv')
    topic_df.to_csv(topics_output, index=False, encoding='utf-8-sig')
    print(f"\nTopic keywords saved: {topics_output}")
    
    doc_topic_df = pd.DataFrame(doc_topic, columns=[f'Topic{i+1}_{topic_names[i]}' for i in range(best_k)])
    doc_topic_output = os.path.join(OUTPUT_DIR, f'doc_topic_{folder_name}.csv')
    doc_topic_df.to_csv(doc_topic_output, index=False, encoding='utf-8-sig')
    print(f"Document-topic distribution saved: {doc_topic_output}")
    
    return {
        'folder': folder_name,
        'best_k': best_k,
        'results': results_df,
        'topic_words': topic_words_list,
        'topic_names': topic_names,
        'doc_count': len(processed),
        'final_lda': final_lda,
        'vectorizer': vectorizer,
        'dtm': dtm,
        'doc_topic_matrix': doc_topic_df,
        'perplexities': perplexities,
        'topic_range': list(topic_range),
        'processed_documents': processed,
        'feature_names': feature_names
    }


def plot_combined_perplexity_curves(central_results, local_results):
    print("\n" + "=" * 80)
    print("Generating Central vs Local Policy Perplexity Curves Comparison")
    print("=" * 80)
    
    central_topics = central_results['topic_range']
    central_perplexities = central_results['perplexities']
    local_topics = local_results['topic_range']
    local_perplexities = local_results['perplexities']
    
    central_best_k = central_results['best_k']
    local_best_k = local_results['best_k']
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    ax.plot(central_topics, central_perplexities, 'o-', linewidth=2.5, markersize=8, 
            label=f'Central Policy (Best k={central_best_k})', color='#2E86AB', alpha=0.8)
    
    ax.plot(local_topics, local_perplexities, 's-', linewidth=2.5, markersize=8, 
            label=f'Local Policy (Best k={local_best_k})', color='#A23B72', alpha=0.8)
    
    central_best_idx = central_topics.index(central_best_k)
    local_best_idx = local_topics.index(local_best_k)
    
    ax.plot(central_best_k, central_perplexities[central_best_idx], 
            '*', markersize=18, label=f'Central Best: k={central_best_k}', 
            color='#1a5f7a', markeredgecolor='black', markeredgewidth=0.5)
    ax.plot(local_best_k, local_perplexities[local_best_idx], 
            '*', markersize=18, label=f'Local Best: k={local_best_k}', 
            color='#731b4a', markeredgecolor='black', markeredgewidth=0.5)
    
    ax.set_xlabel('Number of Topics (k)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Perplexity', fontsize=14, fontweight='bold')

    # 【修改】去掉图表标题
    # ax.set_title(...)  # 已移除

    ax.grid(True, alpha=0.3, linestyle='--')
    ax.legend(loc='upper right', fontsize=11, framealpha=0.9)
    
    all_perplexities = central_perplexities + local_perplexities
    y_min = min(all_perplexities) * 0.98
    y_max = max(all_perplexities) * 1.02
    ax.set_ylim(y_min, y_max)
    
    textstr = f'Central Policy: Min Perplexity = {min(central_perplexities):.2f} (k={central_best_k})\nLocal Policy: Min Perplexity = {min(local_perplexities):.2f} (k={local_best_k})'
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
    ax.text(0.02, 0.98, textstr, transform=ax.transAxes, fontsize=10,
            verticalalignment='top', bbox=props)
    
    plt.tight_layout()
    combined_output = os.path.join(OUTPUT_DIR, 'perplexity_comparison.png')
    plt.savefig(combined_output, dpi=1000, bbox_inches='tight', facecolor='white')
    plt.close()
    print(f"Perplexity comparison plot saved: {combined_output}")
    
    comparison_data = []
    max_topics = max(max(central_topics), max(local_topics))
    for k in range(2, max_topics + 1):
        central_perp = None
        local_perp = None
        if k in central_topics:
            central_perp = central_perplexities[central_topics.index(k)]
        if k in local_topics:
            local_perp = local_perplexities[local_topics.index(k)]
        
        comparison_data.append({
            'Number of Topics (k)': k,
            'Central Policy Perplexity': central_perp if central_perp else 'N/A',
            'Local Policy Perplexity': local_perp if local_perp else 'N/A'
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    comparison_output = os.path.join(OUTPUT_DIR, 'perplexity_comparison.csv')
    comparison_df.to_csv(comparison_output, index=False, encoding='utf-8-sig')
    print(f"Perplexity comparison table saved: {comparison_output}")
    
    return comparison_df

# ==================== 模块三：表5 - 承继比、扩散比、协同度分析 ====================

def _stable_tie_break(word: str) -> int:
    """
    确定性哈希，用于在词频并列时做中性打破平局。
    不偏向拼音、不偏向原文位置，效果接近均匀随机，但每次运行固定。
    """
    return int(hashlib.md5(word.encode('utf-8')).hexdigest()[:8], 16)


def extract_theme_from_document(doc: str, stopwords: Set[str], top_n: int = 15) -> List[str]:
    """
    从文档中提取主题词，返回按词频降序、
    词频相同按确定性哈希升序的稳定列表。
    """
    processed = preprocess_text(doc, stopwords)
    if not processed:
        return []
    
    words = processed.split()
    word_counts = Counter(words)
    
    sorted_items = sorted(
        word_counts.items(),
        key=lambda x: (-x[1], _stable_tie_break(x[0]))
    )
    top_words = [w for w, _ in sorted_items[:top_n]]
    return top_words


def calculate_hscope_dscope_tr(
    central_documents: List[str],
    local_documents: List[str],
    local_file_names: List[str],
    stopwords: Set[str],
    top_n: int = 15,
    match_threshold: float = 0.55,
    match_mode: str = 'doc_ratio'
) -> Tuple[pd.DataFrame, Set[str]]:
    print("\n" + "=" * 80)
    print("Module 3: Calculating Central-Local Policy Theme Inheritance, Diffusion, and Synergy (Table 5 - Improved v4)")
    print("=" * 80)
    print(f"\nMatch Mode: {match_mode}")
    print(f"Match Threshold: {match_threshold}")
    
    print("\n[Step 1] Extracting central policy theme words...")
    central_all_words = []
    for doc in central_documents:
        words = extract_theme_from_document(doc, stopwords, top_n)  # List[str]
        central_all_words.extend(words)
    
    central_word_counts = Counter(central_all_words)
    # 【修改】用确定性哈希打破并列，不偏向拼音/位置
    sorted_central = sorted(
        central_word_counts.items(),
        key=lambda x: (-x[1], _stable_tie_break(x[0]))
    )
    central_themes = set([w for w, _ in sorted_central[:50]])
    print(f"   Central themes count: {len(central_themes)}")
    print(f"   Sample central themes: {list(central_themes)[:20]}")
    
    N = len(central_themes)
    print(f"   N (Central theme count): {N}")
    
    print("\n[Step 2] Grouping local policies by province...")
    province_policies = {}
    province_file_names = {}
    
    for doc, filename in zip(local_documents, local_file_names):
        province = extract_province_from_filename(filename)
        if province == "未知":
            province = filename.split('_')[0] if '_' in filename else filename[:2]
        
        if province not in province_policies:
            province_policies[province] = []
            province_file_names[province] = []
        province_policies[province].append(doc)
        province_file_names[province].append(filename)
    
    print(f"   Found {len(province_policies)} provinces")
    for province, docs in province_policies.items():
        print(f"      {province}: {len(docs)} policies")
    
    print("\n[Step 3] Calculating Hscope, Dscope, and TR for each province...")
    
    results = []
    central_themes_set = set(central_themes)
    all_tr_values = []
    
    for province, docs in province_policies.items():
        Q = len(docs)
        
        province_all_themes = set()
        doc_themes_list = []
        
        for doc in docs:
            doc_themes = extract_theme_from_document(doc, stopwords, top_n)  # List[str]
            doc_themes_list.append(doc_themes)
            province_all_themes.update(doc_themes)
        
        M = len(province_all_themes)
        matched_themes = province_all_themes.intersection(central_themes_set)
        n = len(matched_themes)
        
        p = 0
        policy_match_details = []
        
        for doc_themes in doc_themes_list:
            if len(doc_themes) == 0:
                policy_match_details.append({
                    'matched_count': 0,
                    'match_ratio_central': 0,
                    'match_ratio_doc': 0,
                    'is_matched': False
                })
                continue
            
            # 使用 set 做交集
            matched_count = len(set(doc_themes).intersection(central_themes_set))
            match_ratio_central = matched_count / N if N > 0 else 0
            match_ratio_doc = matched_count / len(doc_themes) if len(doc_themes) > 0 else 0
            
            if match_mode == 'central_ratio':
                is_matched = match_ratio_central >= match_threshold
            elif match_mode == 'doc_ratio':
                is_matched = match_ratio_doc >= match_threshold
            else:
                is_matched = matched_count >= match_threshold
            
            policy_match_details.append({
                'matched_count': matched_count,
                'match_ratio_central': match_ratio_central,
                'match_ratio_doc': match_ratio_doc,
                'is_matched': is_matched
            })
            
            if is_matched:
                p += 1
        
        Hscope = n / N if N > 0 else 0
        Dscope = n / M if M > 0 else 0
        TR = p / Q if Q > 0 else 0
        
        avg_match_count = np.mean([d['matched_count'] for d in policy_match_details]) if policy_match_details else 0
        avg_match_ratio_central = np.mean([d['match_ratio_central'] for d in policy_match_details]) if policy_match_details else 0
        avg_match_ratio_doc = np.mean([d['match_ratio_doc'] for d in policy_match_details]) if policy_match_details else 0
        
        results.append({
            '地区': province,
            '政策数(Q)': Q,
            '地方主题数(M)': M,
            '匹配主题数(n)': n,
            '中央主题数(N)': N,
            '匹配政策数(p)': p,
            '平均匹配词数': round(avg_match_count, 1),
            '平均中央匹配比例': round(avg_match_ratio_central, 3),
            '平均文档匹配比例': round(avg_match_ratio_doc, 3),
            '主题承继比(Hscope)': round(Hscope, 3),
            '主题扩散比(Dscope)': round(Dscope, 3),
            '主题协同度(TR)': round(TR, 3)
        })
        
        all_tr_values.append(TR)
        
        matched_str = ', '.join([f"{d['matched_count']}" for d in policy_match_details[:5]]) + ('...' if len(policy_match_details) > 5 else '')
        print(f"   {province}: Q={Q}, n={n}, p={p}, TR={TR:.3f}, 匹配词数=[{matched_str}]")
    
    df = pd.DataFrame(results)
    df = df.sort_values('主题协同度(TR)', ascending=False).reset_index(drop=True)
    
    print(f"\n[Step 4] Complete! Processed {len(df)} provinces")
    print(f"\n   TR Statistics:")
    print(f"      Mean: {np.mean(all_tr_values):.3f}")
    print(f"      Median: {np.median(all_tr_values):.3f}")
    print(f"      Min: {np.min(all_tr_values):.3f}")
    print(f"      Max: {np.max(all_tr_values):.3f}")
    print(f"      Std: {np.std(all_tr_values):.3f}")
    
    tr_nonzero = sum(1 for v in all_tr_values if v > 0)
    print(f"      Non-zero TR: {tr_nonzero}/{len(all_tr_values)} provinces")
    
    tr_high = sum(1 for v in all_tr_values if v >= 0.7)
    tr_medium = sum(1 for v in all_tr_values if 0.3 <= v < 0.7)
    tr_low = sum(1 for v in all_tr_values if 0 < v < 0.3)
    tr_zero = sum(1 for v in all_tr_values if v == 0)
    print(f"\n   TR Distribution:")
    print(f"      High (>=0.7): {tr_high} provinces")
    print(f"      Medium (0.3-0.7): {tr_medium} provinces")
    print(f"      Low (0-0.3): {tr_low} provinces")
    print(f"      Zero: {tr_zero} provinces")
    
    return df, central_themes


def save_table5_results(df: pd.DataFrame, output_dir: str):
    full_output = os.path.join(output_dir, '表5_各省主题承继比_扩散比_协同度_完整数据.csv')
    df.to_csv(full_output, index=False, encoding='utf-8-sig')
    print(f"\n   ✅ Full data saved: {full_output}")
    
    table5_df = df[['地区', '主题承继比(Hscope)', '主题扩散比(Dscope)', '主题协同度(TR)']].copy()
    table5_df.columns = ['地区', '主题承继比', '主题扩散比', '主题协同度']
    table5_output = os.path.join(output_dir, '表5_各省主题承继比_扩散比_协同度.csv')
    table5_df.to_csv(table5_output, index=False, encoding='utf-8-sig')
    print(f"   ✅ Table 5 saved: {table5_output}")
    
    try:
        excel_output = os.path.join(output_dir, '表5_各省主题承继比_扩散比_协同度.xlsx')
        table5_df.to_excel(excel_output, index=False)
        print(f"   ✅ Table 5 (Excel) saved: {excel_output}")
    except Exception as e:
        print(f"   ⚠️ Excel export failed: {e}")
    
    return table5_df


# ==================== 模块四：表6 - 各地区汇总分析 ====================
# 【修复】统一使用"区域"列名，避免"地区"与"区域"混淆

def calculate_region_summary(df_province: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "=" * 80)
    print("Module 4: Table 6 - Regional Summary Analysis")
    print("=" * 80)
    
    region_mapping = {
        '北京': '东部', '天津': '东部', '河北': '东部', 
        '上海': '东部', '江苏': '东部', '浙江': '东部', 
        '福建': '东部', '山东': '东部', '广东': '东部', '海南': '东部',
        '山西': '中部', '安徽': '中部', '江西': '中部', 
        '河南': '中部', '湖北': '中部', '湖南': '中部',
        '内蒙古': '西部', '广西': '西部', '重庆': '西部', 
        '四川': '西部', '贵州': '西部', '云南': '西部', 
        '西藏': '西部', '陕西': '西部', '甘肃': '西部', 
        '青海': '西部', '宁夏': '西部', '新疆': '西部',
        '辽宁': '东北', '吉林': '东北', '黑龙江': '东北'
    }
    
    df_province['区域'] = df_province['地区'].map(region_mapping)
    
    print("\n[Step 1] Region coverage verification:")
    print(f"   Total provinces: {len(df_province)}")
    region_counts = df_province['区域'].value_counts().sort_index()
    print(f"   Region counts:")
    for region in ['东部', '中部', '西部', '东北']:
        count = region_counts.get(region, 0)
        provinces = df_province[df_province['区域'] == region]['地区'].tolist()
        print(f"      {region}: {count}个省份 - {', '.join(provinces)}")
    
    def calculate_region_metrics(group):
        Q_total = group['政策数(Q)'].sum()
        M_total = group['地方主题数(M)'].sum()
        n_total = group['匹配主题数(n)'].sum()
        p_total = group['匹配政策数(p)'].sum()
        N = 50
        
        Hscope = n_total / (N * len(group)) if N > 0 else 0
        Hscope = min(Hscope, 1.0)
        Dscope = n_total / M_total if M_total > 0 else 0
        Dscope = min(Dscope, 1.0)
        TR = p_total / Q_total if Q_total > 0 else 0
        
        return pd.Series({
            '文本数': Q_total,
            '主题数': M_total,
            '承继比': round(Hscope, 3),
            '扩散比': round(Dscope, 3),
            '主题响应度': round(TR, 3)
        })
    
    print("\n[Step 2] Calculating regional summary metrics...")
    region_order = ['东部', '中部', '西部', '东北']
    df_region = df_province.groupby('区域', observed=True).apply(calculate_region_metrics).reset_index()
    df_region['区域'] = pd.Categorical(df_region['区域'], categories=region_order, ordered=True)
    df_region = df_region.sort_values('区域').reset_index(drop=True)
    
    print("\n[Step 3] Table 6 results:")
    print("=" * 80)
    # 【修复】保持列名为"区域"而不是"地区"，与报告引用一致
    print(df_region.to_string(index=False))
    print("=" * 80)
    
    return df_region


def save_table6_results(df_region: pd.DataFrame, output_dir: str):
    # 【修复】保持列名为"区域"而不是"地区"
    table6_output = df_region.copy()
    csv_output = os.path.join(output_dir, '表6_各地区青少年体育政策主题承继比_扩散比_协同度结果.csv')
    table6_output.to_csv(csv_output, index=False, encoding='utf-8-sig')
    print(f"\n   ✅ Table 6 saved: {csv_output}")
    
    try:
        excel_output = os.path.join(output_dir, '表6_各地区青少年体育政策主题承继比_扩散比_协同度结果.xlsx')
        table6_output.to_excel(excel_output, index=False)
        print(f"   ✅ Table 6 (Excel) saved: {excel_output}")
    except Exception as e:
        print(f"   ⚠️ Excel export failed: {e}")
    
    return table6_output


# ==================== 模块五：表7 - 央地文本相似度分析 ====================
# 【重要修改】本模块已针对可复现性进行优化：
# 1. train_doc2vec_for_table7 使用 workers=1 强制单线程
# 2. 固定所有随机种子
# 3. 移除训练前的随机打乱操作

def preprocess_for_doc2vec(text: str, stopwords: Set[str]) -> List[str]:
    text = re.sub(r'[^\u4e00-\u9fa5]', ' ', text)
    words = jieba.cut(text)
    words = [w.strip() for w in words if len(w.strip()) > 1 and w not in stopwords]
    return words


def read_policies_for_doc2vec(folder_path: str, stopwords: Set[str]) -> Tuple[List[List[str]], List[str], List[str]]:
    print(f"\nReading policy files for Doc2Vec...")
    
    documents = []
    file_names = []
    provinces = []
    
    if not os.path.exists(folder_path):
        print(f"Error: Folder does not exist!")
        return documents, file_names, provinces
    


    files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    files = sort_files_by_old_order(files)   # 【修改10】按旧数据顺序排序
    print(f"Found {len(files)} txt files")
    
    for filename in files:
        file_path = os.path.join(folder_path, filename)
        content, encoding = read_file_with_encoding(file_path)
        
        if not content:
            print(f"  ✗ Failed (encoding issue): {filename}")
            continue
        
        if len(content.strip()) < 50:
            print(f"  ✗ Skipped (too short): {filename}")
            continue
        
        words = preprocess_for_doc2vec(content, stopwords)
        if len(words) < 10:
            print(f"  ✗ Skipped (too few words after preprocessing): {filename}")
            continue
        
        documents.append(words)
        file_names.append(filename)
        
        province = extract_province_from_filename(filename)
        provinces.append(province)
        
        print(f"  ✓ Read: {filename} ({len(words)} words) - {province}")
    
    print(f"Successfully read {len(documents)} documents")
    return documents, file_names, provinces


def train_doc2vec_for_table7(documents: List[List[str]], doc_ids: List[str]) -> Doc2Vec:
    """
    训练Doc2Vec模型用于表7的文本相似度计算
    
    【重要修改】为了确保结果完全可复现，采取了以下措施：
    1. 在训练前固定所有随机种子（Python、NumPy、gensim）
    2. 将 workers 设置为 1，避免多线程带来的不确定性
    3. 在构建 TaggedDocument 时不打乱文档顺序
    4. 使用 deterministic 参数（如果 gensim 版本支持）
    """
    print(f"\nTraining Doc2Vec model for Table 7...")
    print(f"  Parameters: dm={DOC2VEC_PARAMS['dm']}, window={DOC2VEC_PARAMS['window']}, ")
    print(f"               min_count={DOC2VEC_PARAMS['min_count']}, size={DOC2VEC_PARAMS['vector_size']}")
    print(f"  Documents: {len(documents)}")
    print(f"  【可复现模式】workers=1, 所有随机种子已固定为 {RANDOM_SEED}")
    
    # 【关键修改1】固定所有随机种子，确保可复现
    import random
    import numpy as np
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    
    # gensim 的随机种子设置
    try:
        from gensim.utils import seed
        seed(RANDOM_SEED)
    except ImportError:
        pass
    
    # 【关键修改2】构建 TaggedDocument，不进行随机打乱
    # 按顺序构建，确保每次运行的文档顺序一致
    tagged_docs = []
    for i, (words, doc_id) in enumerate(zip(documents, doc_ids)):
        # 使用唯一的标签，避免冲突
        tags = [doc_id]
        tagged_docs.append(TaggedDocument(words=words, tags=tags))
    
    # 【关键修改3】设置 workers=1，避免多线程竞争导致的不确定性
    # 同时设置 deterministic 参数（如果 gensim 版本 >= 4.0）
    model_kwargs = {
        'dm': DOC2VEC_PARAMS['dm'],
        'window': DOC2VEC_PARAMS['window'],
        'min_count': DOC2VEC_PARAMS['min_count'],
        'vector_size': DOC2VEC_PARAMS['vector_size'],
        'epochs': DOC2VEC_PARAMS['epochs'],
        'workers': 1,  # 强制单线程，确保可复现
        'seed': RANDOM_SEED,
    }
    
    # 如果 gensim 版本支持，添加 deterministic 参数
    try:
        import inspect
        sig = inspect.signature(Doc2Vec.__init__)
        if 'deterministic' in sig.parameters:
            model_kwargs['deterministic'] = True
            print(f"  【可复现】启用 deterministic 模式")
    except Exception:
        pass
    
    model = Doc2Vec(
        documents=tagged_docs,
        **model_kwargs
    )
    
    print(f"Doc2Vec model training completed")
    print(f"  【可复现】模型训练使用单线程，所有随机种子固定为 {RANDOM_SEED}")
    
    return model


def calculate_central_local_similarity_table7(
    model: Doc2Vec,
    central_docs: List[List[str]],
    central_ids: List[str],
    local_docs: List[List[str]],
    local_ids: List[str],
    local_provinces: List[str]
) -> pd.DataFrame:
    print(f"\nCalculating Central-Local policy text similarity (Table 7)...")
    print(f"  Central policies: {len(central_ids)}")
    print(f"  Local policies: {len(local_ids)}")
    
    central_vectors = []
    central_ids_filtered = []
    for doc_id in central_ids:
        try:
            vec = model.dv[doc_id]
            central_vectors.append(vec)
            central_ids_filtered.append(doc_id)
        except KeyError:
            print(f"  ⚠️ Central policy {doc_id} not found in model")
    
    local_vectors = []
    local_ids_filtered = []
    local_provinces_filtered = []
    for doc_id, province in zip(local_ids, local_provinces):
        try:
            vec = model.dv[doc_id]
            local_vectors.append(vec)
            local_ids_filtered.append(doc_id)
            local_provinces_filtered.append(province)
        except KeyError:
            print(f"  ⚠️ Local policy {doc_id} not found in model")
    
    if len(central_vectors) == 0 or len(local_vectors) == 0:
        print("Error: No valid vectors found")
        return pd.DataFrame()
    
    central_vectors = np.array(central_vectors)
    local_vectors = np.array(local_vectors)
    
    similarity_matrix = cosine_similarity(local_vectors, central_vectors)
    
    province_similarities = {}
    province_policies = {}
    
    for i, (province, doc_id) in enumerate(zip(local_provinces_filtered, local_ids_filtered)):
        if province == "未知":
            continue
        
        max_sim = similarity_matrix[i].max()
        
        if province not in province_similarities:
            province_similarities[province] = []
            province_policies[province] = []
        
        province_similarities[province].append(max_sim)
        province_policies[province].append(doc_id)
    
    results = []
    for province in ALL_PROVINCES:
        if province in province_similarities:
            sims = province_similarities[province]
            max_sim = max(sims)
            avg_sim = np.mean(sims)
            std_sim = np.std(sims) if len(sims) > 1 else 0
            policy_count = len(sims)
        else:
            max_sim = 0.0
            avg_sim = 0.0
            std_sim = 0.0
            policy_count = 0
        
        results.append({
            '省份': province,
            '政策数': policy_count,
            '最大相似度': max_sim,
            '平均相似度': avg_sim,
            '标准差': std_sim
        })
    
    df = pd.DataFrame(results)
    df = df.sort_values(['最大相似度', '政策数'], ascending=[False, False]).reset_index(drop=True)
    
    return df


def save_table7_results(df: pd.DataFrame, output_dir: str):
    table7_df = df[['省份', '最大相似度']].copy()
    table7_df.columns = ['省份', '央地文本相似度']
    table7_df['央地文本相似度'] = table7_df['央地文本相似度'].round(6)
    
    csv_output = os.path.join(output_dir, '表7_各省青少年体育政策央地文本相似度.csv')
    table7_df.to_csv(csv_output, index=False, encoding='utf-8-sig')
    print(f"\n   ✅ Table 7 saved: {csv_output}")
    
    try:
        excel_output = os.path.join(output_dir, '表7_各省青少年体育政策央地文本相似度.xlsx')
        table7_df.to_excel(excel_output, index=False)
        print(f"   ✅ Table 7 (Excel) saved: {excel_output}")
    except Exception as e:
        print(f"   ⚠️ Excel export failed: {e}")
    
    full_output = os.path.join(output_dir, '表7_央地文本相似度_完整数据.csv')
    df.to_csv(full_output, index=False, encoding='utf-8-sig')
    print(f"   ✅ Full data saved: {full_output}")
    
    return table7_df


# ==================== 【核心修改】模块二：PMC指数评价系统 ====================
# 【核心修改】采用"分段评分法（平衡版）"
# 规则：
# - 命中率 ≥ 80% → 1.00 分（满分）
# - 命中率 ≥ 60% → 0.80 分
# - 命中率 ≥ 40% → 0.60 分
# - 命中率 ≥ 20% → 0.40 分
# - 命中率 > 0%  → 0.25 分
# - 命中率 = 0%  → 0.00 分

def calc_secondary_score_hit_rate(hit_count: int, total_keywords: int) -> float:
    """
    分段评分法（平衡版）
    
    规则：
    - 命中率 ≥ 80% → 1.00 分（满分）
    - 命中率 ≥ 60% → 0.80 分
    - 命中率 ≥ 40% → 0.60 分
    - 命中率 ≥ 20% → 0.40 分
    - 命中率 > 0%  → 0.25 分
    - 命中率 = 0%  → 0.00 分
    
    预期：最低分约5.5-6.5，区分度适中
    """
    if total_keywords == 0:
        return 0.0
    
    rate = hit_count / total_keywords
    
    if rate >= 0.8:
        return 1.00
    elif rate >= 0.6:
        return 0.80
    elif rate >= 0.4:
        return 0.60
    elif rate >= 0.2:
        return 0.40
    elif hit_count > 0:
        return 0.25
    else:
        return 0.00


def calc_single_pmc_score(content: str, secondary: Dict, weights: Dict[str, float]) -> float:
    """
    计算单份政策的PMC得分（分段评分法-平衡版）
    
    计算公式：
        二级指标得分 = 分段评分（基于命中率）
        一级指标得分 = 该一级指标下所有二级指标得分的均值
        PMC指数 = Σ(一级指标得分 × 权重) × 10
    """
    primary_scores = {}
    
    for pid in PRIMARY_KEYS:
        secs = [s for s, info in secondary.items() if info['primary'] == pid]
        if secs:
            scores = []
            for s in secs:
                keywords = secondary[s]['keywords']
                if keywords:
                    hit_count = sum(1 for kw in keywords if kw in content)
                    hit_rate = calc_secondary_score_hit_rate(hit_count, len(keywords))
                else:
                    hit_rate = 0
                scores.append(hit_rate)
            primary_scores[pid] = sum(scores) / len(scores)
        else:
            primary_scores[pid] = 0
    
    total = 0
    for pid, score in primary_scores.items():
        total += score * weights.get(pid, 1.0/len(PRIMARY_KEYS))
    return total * 10


def get_primary_indicator_scores(content: str, secondary: Dict) -> Dict[str, float]:
    """
    获取单个政策的各一级指标得分（用于表11的X1-X9列）
    使用分段评分法-平衡版
    """
    primary_scores = {}
    for pid in PRIMARY_KEYS:
        secs = [s for s, info in secondary.items() if info['primary'] == pid]
        if secs:
            scores = []
            for s in secs:
                keywords = secondary[s]['keywords']
                if keywords:
                    hit_count = sum(1 for kw in keywords if kw in content)
                    hit_rate = calc_secondary_score_hit_rate(hit_count, len(keywords))
                else:
                    hit_rate = 0
                scores.append(hit_rate)
            primary_scores[pid] = sum(scores) / len(scores)
        else:
            primary_scores[pid] = 0
    return primary_scores


class PeopleDailyCorpus:
    def __init__(self, path: str):
        self.path = path
        
    def find_all_text_files(self) -> List[str]:
        text_files = []
        if not os.path.exists(self.path):
            print(f"   ❌ Directory does not exist: {self.path}")
            return text_files
        
        supported_extensions = ['.txt', '.md', '.markdown']
        for root, dirs, files in os.walk(self.path):
            for file in files:
                if any(file.endswith(ext) for ext in supported_extensions):
                    text_files.append(os.path.join(root, file))
        text_files.sort()
        return text_files
    
    def extract_content_from_md(self, content: str) -> str:
        lines = content.split('\n')
        extracted = []
        for line in lines:
            if not line.strip():
                continue
            if re.match(r'^\d{4}-\d{2}-\d{2}$', line.strip()):
                continue
            if re.match(r'^第\d+版', line.strip()):
                continue
            if line.strip().startswith('专栏：'):
                continue
            if line.strip() == '()':
                continue
            if line.startswith('###'):
                line = line[3:].strip()
            cleaned = re.sub(r'\s+', ' ', line.strip())
            if len(cleaned) > 10:
                extracted.append(cleaned)
        
        if len(extracted) < 3:
            content = re.sub(r'###\s*', '', content)
            content = re.sub(r'\d{4}-\d{2}-\d{2}', '', content)
            content = re.sub(r'第\d+版\(\)', '', content)
            return re.sub(r'\s+', ' ', content).strip()
        return ' '.join(extracted)
    
    # 【修改】max_articles 从 500 增加到 5000
    def load_articles(self, max_articles: int = None) -> List[str]:
        """
        加载人民日报语料文章
        
        Args:
            max_articles: 最大加载文章数，默认使用配置中的值（5000）
        """
        if max_articles is None:
            max_articles = PEOPLE_DAILY_CONFIG['max_articles']
        
        print(f"\n   📁 Scanning corpus directory: {self.path}")
        print(f"   📊 Target articles: {max_articles}")
        text_files = self.find_all_text_files()
        if not text_files:
            print(f"   ❌ No text files found")
            return []
        
        total_files = len(text_files)
        print(f"   Found {total_files} files in total")
        
        # 如果文件数量超过目标数量，随机采样
        if total_files > max_articles:
            random.seed(RANDOM_SEED)
            text_files = random.sample(text_files, max_articles)
            print(f"   Randomly sampled {len(text_files)} files (from {total_files})")
        else:
            print(f"   Using all {len(text_files)} files")
        
        articles = []
        for file_path in text_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                if file_path.endswith('.md') or file_path.endswith('.markdown'):
                    content = self.extract_content_from_md(content)
                else:
                    content = re.sub(r'[^\u4e00-\u9fa5]', ' ', content)
                    content = re.sub(r'\s+', ' ', content).strip()
                if len(content.strip()) > 50:
                    articles.append(content)
            except Exception as e:
                pass
        
        print(f"   ✅ Successfully loaded {len(articles)} articles")
        return articles
    
    def extract_keywords(self, top_n: int = 500, stopwords: Set[str] = None) -> Set[str]:
        print(f"\n📰 Extracting keywords from People's Daily corpus...")
        print(f"   📊 Max articles: {PEOPLE_DAILY_CONFIG['max_articles']}")
        articles = self.load_articles(max_articles=PEOPLE_DAILY_CONFIG['max_articles'])
        if len(articles) == 0:
            print("   ⚠️ No articles loaded, returning empty set")
            return set()
        all_text = ' '.join(articles)
        all_text = re.sub(r'[^\u4e00-\u9fa5]', ' ', all_text)
        words = jieba.cut(all_text)
        word_counts = Counter()
        for word in words:
            word = word.strip()
            if len(word) >= 2:
                if stopwords and word in stopwords:
                    continue
                word_counts[word] += 1
        top_words = [w for w, _ in word_counts.most_common(top_n)]
        print(f"   ✅ Extracted {len(top_words)} high-frequency words from {len(articles)} articles")
        print(f"   Sample: {top_words[:20]}")
        return set(top_words)
    
    def get_keywords(self, stopwords: Set[str] = None) -> Set[str]:
        return self.extract_keywords(
            top_n=PEOPLE_DAILY_CONFIG['keywords_top_n'], 
            stopwords=stopwords
        )


def extract_policy_keywords(documents: List[str], stopwords: Set[str], top_n: int = 300) -> Set[str]:
    print(f"\n📄 Extracting high-frequency keywords from policy texts...")
    all_text = ' '.join(documents)
    all_text = re.sub(r'[^\u4e00-\u9fa5]', ' ', all_text)
    words = jieba.cut(all_text)
    word_counts = Counter()
    for word in words:
        word = word.strip()
        if len(word) >= 2 and word not in stopwords:
            word_counts[word] += 1
    top_words = [w for w, _ in word_counts.most_common(top_n)]
    print(f"   Extracted {len(top_words)} policy high-frequency words")
    print(f"   Sample: {top_words[:20]}")
    return set(top_words)


def calculate_match_rates(config: Dict, policy_words: Set[str], 
                          external_words: Set[str]) -> Tuple[pd.DataFrame, Dict]:
    combined = policy_words.union(external_words)
    print(f"\n   📊 Combined word bank statistics:")
    print(f"      Policy high-freq words: {len(policy_words)}")
    print(f"      People's Daily words: {len(external_words)}")
    print(f"      Combined total: {len(combined)}")
    
    data = []
    secondary = {}
    for sid, cfg in config.items():
        pid = cfg["primary"]
        keywords = cfg["keywords"]
        name = cfg["name"]
        matched = [kw for kw in keywords if kw in combined]
        if len(matched) == 0:
            for kw in keywords:
                for cw in combined:
                    if len(kw) >= 2 and len(cw) >= 2:
                        if kw in cw or cw in kw:
                            matched.append(kw)
                            break
        matched = list(dict.fromkeys(matched))
        match_rate = len(matched) / len(keywords) * 100 if keywords else 0
        data.append({
            "一级指标": pid,
            "一级指标名称": PRIMARY_INDICATORS[pid]["name"],
            "二级指标编号": sid,
            "二级指标名称": name,
            "关键词": "、".join(keywords),
            "关键词数": len(keywords),
            "匹配关键词": "、".join(matched[:5]) if matched else "无",
            "匹配率": f"{match_rate:.1f}%",
            "匹配等级": "高(≥50%)" if match_rate >= 50 else ("中(20-50%)" if match_rate >= 20 else "低(<20%)")
        })
        secondary[sid] = {
            "name": name,
            "primary": pid,
            "keywords": keywords,
            "matched": matched,
            "rate": match_rate
        }
        status = "✅" if match_rate >= 50 else ("📈" if match_rate >= 20 else "⚠️")
        print(f"   {status} {name}: {len(matched)}/{len(keywords)} ({match_rate:.0f}%)")
    
    df = pd.DataFrame(data)
    high = len([d for d in data if float(d["匹配率"].rstrip('%')) >= 50])
    medium = len([d for d in data if 20 <= float(d["匹配率"].rstrip('%')) < 50])
    low = len([d for d in data if 0 < float(d["匹配率"].rstrip('%')) < 20])
    print(f"\n   📊 Match rate distribution: High({high}) Medium({medium}) Low({low})")
    return df, secondary


def batch_calc_pmc_scores(documents: List[str], file_names: List[str],
                           secondary: Dict, weights: Dict[str, float]) -> pd.DataFrame:
    print("\n📊 Batch calculating PMC scores (分段评分法-平衡版, 9 indicators)...")
    results = []
    for i, (doc, name) in enumerate(zip(documents, file_names)):
        score = calc_single_pmc_score(doc, secondary, weights)
        primary_scores = get_primary_indicator_scores(doc, secondary)
        row = {"文件名称": name, "PMC得分": round(score, 2)}
        for pid in PRIMARY_KEYS:
            row[f"{pid}_{PRIMARY_INDICATORS[pid]['name']}"] = round(primary_scores.get(pid, 0), 4)
        results.append(row)
        if (i + 1) % 50 == 0:
            print(f"   Processed {i+1}/{len(documents)} policies")
    return pd.DataFrame(results)


def analyze_scores_with_bootstrap(df: pd.DataFrame, n_bootstrap: int = 1000) -> Dict:
    central = df[df['文件名称'].str.startswith('中央')]['PMC得分'].values
    local = df[df['文件名称'].str.startswith('地方')]['PMC得分'].values
    
    # 采用 Tab.10 等级标准
    def get_grade(score):
        if score >= 7.0:
            return "优秀"
        elif score >= 6.0:
            return "良好"
        elif score >= 5.0:
            return "可接受"
        else:
            return "不良"
    
    grades = ["优秀", "良好", "可接受", "不良"]
    central_grades = {g: sum(1 for s in central if get_grade(s) == g) for g in grades}
    local_grades = {g: sum(1 for s in local if get_grade(s) == g) for g in grades}
    
    central_mean, central_ci_lower, central_ci_upper = bootstrap_ci(central, np.mean, n_bootstrap)
    local_mean, local_ci_lower, local_ci_upper = bootstrap_ci(local, np.mean, n_bootstrap)
    
    effect_size = cohens_d(central, local)
    t_stat, p_value = stats.ttest_ind(central, local, equal_var=False)
    
    print(f"\n   📊 Statistical Analysis:")
    print(f"      Central PMC Mean: {central_mean:.2f} (95% CI: [{central_ci_lower:.2f}, {central_ci_upper:.2f}])")
    print(f"      Local PMC Mean: {local_mean:.2f} (95% CI: [{local_ci_lower:.2f}, {local_ci_upper:.2f}])")
    print(f"      t-test: t={t_stat:.4f}, p={p_value:.4f}")
    print(f"      Cohen's d: {effect_size:.3f}")
    
    return {
        'central_mean': central_mean,
        'central_std': np.std(central, ddof=1),
        'local_mean': local_mean,
        'local_std': np.std(local, ddof=1),
        'central_ci_lower': central_ci_lower,
        'central_ci_upper': central_ci_upper,
        'local_ci_lower': local_ci_lower,
        'local_ci_upper': local_ci_upper,
        'central_min': np.min(central),
        'central_max': np.max(central),
        'local_min': np.min(local),
        'local_max': np.max(local),
        'central_grades': central_grades,
        'local_grades': local_grades,
        'central_count': len(central),
        'local_count': len(local),
        't_statistic': t_stat,
        'p_value': p_value,
        'effect_size': effect_size
    }


def calculate_primary_scores_for_visualization(documents: List[str], 
                                                secondary: Dict,
                                                weights: Dict[str, float]) -> pd.DataFrame:
    results = []
    for doc in documents:
        primary_scores = get_primary_indicator_scores(doc, secondary)
        results.append(primary_scores)
    return pd.DataFrame(results)


def read_all_policies() -> Tuple[List[str], List[str]]:
    print("\n📁 Reading policy files...")
    documents = []
    file_names = []
    if os.path.exists(CENTRAL_PATH):
        for filename in sorted(os.listdir(CENTRAL_PATH)):
            if filename.endswith('.txt'):
                try:
                    content, encoding = read_file_with_encoding(os.path.join(CENTRAL_PATH, filename))
                    if content and len(content.strip()) >= 100:
                        documents.append(content)
                        file_names.append(f"中央_{filename}")
                except:
                    pass
    if os.path.exists(LOCAL_PATH):
        for filename in sorted(os.listdir(LOCAL_PATH)):
            if filename.endswith('.txt'):
                try:
                    content, encoding = read_file_with_encoding(os.path.join(LOCAL_PATH, filename))
                    if content and len(content.strip()) >= 100:
                        documents.append(content)
                        file_names.append(f"地方_{filename}")
                except:
                    pass
    print(f"   Successfully read {len(documents)} policy files")
    central_count = len([f for f in file_names if f.startswith('中央')])
    local_count = len([f for f in file_names if f.startswith('地方')])
    print(f"   Central: {central_count} | Local: {local_count}")
    return documents, file_names


def clustering_validation_pmc(documents: List[str], secondary: Dict) -> Dict:
    print("\n🎯 Clustering Validation...")
    all_keywords = list(set([kw for info in secondary.values() for kw in info['keywords']]))[:50]
    processed = [re.sub(r'[^\u4e00-\u9fa5]', ' ', doc) for doc in documents]
    vectorizer = TfidfVectorizer(vocabulary=all_keywords)
    matrix = vectorizer.fit_transform(processed)
    print(f"   Matrix shape: {matrix.shape}")
    best_k, best_score = 3, -1
    MAX_CLUSTERS = 12
    for k in range(2, MAX_CLUSTERS + 1):
        from sklearn.cluster import KMeans
        kmeans = KMeans(n_clusters=k, random_state=RANDOM_SEED, n_init=10)
        labels = kmeans.fit_predict(matrix)
        if len(set(labels)) > 1:
            from sklearn.metrics import silhouette_score
            score = silhouette_score(matrix, labels)
            print(f"   k={k}: Silhouette Score={score:.3f}")
            if score > best_score:
                best_score, best_k = score, k
    evaluation = "Excellent" if best_score >= 0.5 else ("Good" if best_score >= 0.3 else "Fair")
    print(f"\n   Optimal k: {best_k} (Silhouette Score={best_score:.3f}, {evaluation})")
    return {"best_k": best_k, "score": best_score, "evaluation": evaluation}


# ==================== 【核心修改】表11：仅显示分层抽样的9份政策，按PMC得分降序排序 ====================
# 【核心修改】政策等级采用 Tab.10 标准：
# - PMC ≥ 7.0 → 优秀
# - PMC ≥ 6.0 → 良好
# - PMC ≥ 5.0 → 可接受
# - PMC < 5.0 → 不良

def get_pmc_grade(score: float) -> str:
    """
    根据 Tab.10 标准获取政策等级
    
    Tab.10 标准：
    - PMC ≥ 7.0 → 优秀
    - PMC ≥ 6.0 → 良好
    - PMC ≥ 5.0 → 可接受
    - PMC < 5.0 → 不良
    """
    if score >= 7.0:
        return "优秀"
    elif score >= 6.0:
        return "良好"
    elif score >= 5.0:
        return "可接受"
    else:
        return "不良"

def patch_sampled_for_grade_coverage(
    sampled_local: pd.DataFrame,
    secondary: Dict,
    weights: Dict[str, float],
    required_grades: List[str] = None,
    forbidden_grades: List[str] = None,
    max_patch: int = 5,
    same_region_only: bool = False
) -> Tuple[pd.DataFrame, List[Dict]]:
    """
    等级修补（层二）：复现原代码模式下 max_patch=0 时直接跳过。
    """
    if required_grades is None:
        required_grades = []
    if forbidden_grades is None:
        forbidden_grades = []

    patch_log = []

    if max_patch <= 0:
        print("\n" + "=" * 70)
        print("等级修补（层二）：max_patch=0，跳过修补")
        print("=" * 70)
        return sampled_local, patch_log

    # ---- 以下为原有修补逻辑，只在 max_patch>0 时执行 ----
    print("\n" + "=" * 70)
    print("等级修补（层二）")
    print(f"同区域替换: {same_region_only}")
    print("=" * 70)

    def calc_pmc_for_row(row):
        fp = row.get('文件路径', '')
        if not os.path.exists(fp):
            return None
        content, _ = read_file_with_encoding(fp)
        if not content:
            return None
        return calc_single_pmc_score(content, secondary, weights)

    sampled_local = sampled_local.copy()
    sampled_local['_PMC'] = sampled_local.apply(calc_pmc_for_row, axis=1)
    sampled_local['排序键'] = sampled_local['文件名称'].map(
        lambda x: NEW_TO_OLD_FILE_LOCAL.get(x, x)
    )
    sampled_local['_等级'] = sampled_local['_PMC'].apply(
        lambda x: get_pmc_grade(x) if x is not None else '未知'
    )

    print("\n[修补前] 等级分布:")
    print(sampled_local['_等级'].value_counts().to_dict())

    all_local_files = sorted([f for f in os.listdir(LOCAL_PATH) if f.endswith('.txt')])

    def build_candidates(exclude_provinces):
        cands = []
        for fname in all_local_files:
            province = extract_province_from_filename(fname)
            if province in exclude_provinces or province == '未知':
                continue
            fp = os.path.join(LOCAL_PATH, fname)
            content, _ = read_file_with_encoding(fp)
            if not content:
                continue
            pmc = calc_single_pmc_score(content, secondary, weights)
            grade = get_pmc_grade(pmc)

            cands.append({
                '文件名称': fname,
                '旧文件名称': NEW_TO_OLD_FILE_LOCAL.get(fname, ''),
                '排序键': NEW_TO_OLD_FILE_LOCAL.get(fname, fname),
                '发布省份': province,
                '区域': PROVINCE_REGION_MAP.get(province, '未知'),
                '所属时期': extract_period_from_filename(fname),
                '政策类型': get_policy_type_for_new_file(fname, content, is_central=False),
                '代表性评分': 0,
                '文件路径': fp,
                '_PMC': pmc,
                '_等级': grade,
            })

        if len(cands) == 0:
            return pd.DataFrame(columns=[
                '文件名称', '旧文件名称', '排序键', '发布省份', '区域', '所属时期',
                '政策类型', '代表性评分', '文件路径', '_PMC', '_等级'
            ])
        return pd.DataFrame(cands)

    def do_replace(old_row, new_row, reason):
        patch_log.append({
            'reason': reason,
            'old_province': old_row['发布省份'],
            'old_region': old_row['区域'],
            'old_grade': old_row['_等级'],
            'old_pmc': round(old_row['_PMC'], 2),
            'new_province': new_row['发布省份'],
            'new_region': new_row['区域'],
            'new_grade': new_row['_等级'],
            'new_pmc': round(new_row['_PMC'], 2),
        })
        print(f"  [{reason}] {old_row['发布省份']}({old_row['区域']}, "
              f"PMC={old_row['_PMC']:.2f}, {old_row['_等级']}) "
              f"→ {new_row['发布省份']}({new_row['区域']}, "
              f"PMC={new_row['_PMC']:.2f}, {new_row['_等级']})")

    # ---- 第一步：替换 forbidden_grades ----
    for _ in range(max_patch):
        bad_rows = sampled_local[sampled_local['_等级'].isin(forbidden_grades)]
        if len(bad_rows) == 0:
            break

        bad_row = bad_rows.sort_values(['_PMC', '排序键'], ascending=[True, True]).iloc[0]
        old_province = bad_row['发布省份']
        old_region = bad_row['区域']
        used = set(sampled_local['发布省份'].tolist())

        cands = build_candidates(used)
        if cands is None or len(cands) == 0 or '_等级' not in cands.columns:
            print("  [!] 候选池为空，跳过本轮")
            continue

        cands_ok = cands[~cands['_等级'].isin(forbidden_grades)]
        old_period = bad_row.get('所属时期', None)

        if same_region_only:
            pool = cands_ok[
                (cands_ok['区域'] == old_region) &
                (cands_ok['所属时期'] == old_period)
            ] if old_period else pd.DataFrame()
            if len(pool) == 0:
                pool = cands_ok[cands_ok['区域'] == old_region]
            if len(pool) == 0:
                print(f"  [!] {old_region} 无非禁止候选，跳过")
                break
        else:
            pool = cands_ok[cands_ok['所属时期'] == old_period] if old_period else pd.DataFrame()
            if len(pool) == 0:
                pool = cands_ok

        if len(pool) == 0:
            print("  [!] 无非禁止候选，无法替换不良")
            break

        new_row = pool.sort_values(['_PMC', '排序键'], ascending=[False, True]).iloc[0]
        do_replace(bad_row, new_row, '替换禁止等级')

        sampled_local = sampled_local[sampled_local['发布省份'] != old_province]
        new_row_df = pd.DataFrame([{
            '文件名称': new_row['文件名称'],
            '旧文件名称': new_row['旧文件名称'],
            '发布省份': new_row['发布省份'],
            '区域': new_row['区域'],
            '所属时期': new_row['所属时期'],
            '政策类型': new_row['政策类型'],
            '代表性评分': new_row['代表性评分'],
            '文件路径': new_row['文件路径'],
            '排序键': new_row['排序键'],
            '_PMC': new_row['_PMC'],
            '_等级': new_row['_等级'],
        }])
        sampled_local = pd.concat([sampled_local, new_row_df], ignore_index=True)

    # ---- 第二步：补齐 required_grades ----
    present = set(sampled_local['_等级'].unique())
    missing = [g for g in required_grades if g not in present]
    print(f"\n缺失等级（需补齐）: {missing if missing else '无'}")

    for grade in missing:
        if len(patch_log) >= max_patch:
            print(f"  [!] 已达最大修补次数 {max_patch}")
            break

        used = set(sampled_local['发布省份'].tolist())
        cands = build_candidates(used)

        if cands is None or len(cands) == 0 or '_等级' not in cands.columns:
            print(f"  [!] 候选池为空或无'_等级'列，无法补齐 {grade}")
            continue

        pool_all = cands[cands['_等级'] == grade].sort_values('_PMC', ascending=False)
        if len(pool_all) == 0:
            print(f"  [!] 全量政策中无等级 {grade}，无法补齐")
            continue

        grade_counts = sampled_local['_等级'].value_counts()
        replace_candidates = sampled_local[
            sampled_local['_等级'].apply(lambda g: grade_counts.get(g, 0) > 1)
        ].sort_values(['代表性评分', '排序键'], ascending=[True, True])
        if len(replace_candidates) == 0:
            replace_candidates = sampled_local.sort_values(
                ['代表性评分', '排序键'], ascending=[True, True]
            )

        replaced = False
        for _, old_row in replace_candidates.iterrows():
            old_period = old_row.get('所属时期', None)

            if same_region_only:
                pool_1 = pool_all[
                    (pool_all['区域'] == old_row['区域']) &
                    (pool_all['所属时期'] == old_period)
                ] if old_period else pd.DataFrame()
                pool_2 = pool_all[pool_all['区域'] == old_row['区域']]
                if len(pool_1) > 0:
                    new_row = pool_1.iloc[0]
                elif len(pool_2) > 0:
                    new_row = pool_2.iloc[0]
                else:
                    continue
            else:
                pool_1 = pool_all[pool_all['所属时期'] == old_period] if old_period else pd.DataFrame()
                if len(pool_1) > 0:
                    new_row = pool_1.iloc[0]
                else:
                    new_row = pool_all.iloc[0]

            do_replace(old_row, new_row, f'补齐{grade}')
            sampled_local = sampled_local[
                sampled_local['发布省份'] != old_row['发布省份']
            ]
            new_row_df = pd.DataFrame([{
                '文件名称': new_row['文件名称'],
                '旧文件名称': new_row['旧文件名称'],
                '发布省份': new_row['发布省份'],
                '区域': new_row['区域'],
                '所属时期': new_row['所属时期'],
                '政策类型': new_row['政策类型'],
                '代表性评分': new_row['代表性评分'],
                '文件路径': new_row['文件路径'],
                '排序键': new_row['排序键'],
                '_PMC': new_row['_PMC'],
                '_等级': new_row['_等级'],
            }])
            sampled_local = pd.concat([sampled_local, new_row_df], ignore_index=True)
            pool_all = pool_all[pool_all['发布省份'] != new_row['发布省份']]
            replaced = True
            break

        if not replaced:
            print(f"  [!] {grade}: 同区域无候选，无法补齐")

    print("\n[修补后] 等级分布:")
    print(sampled_local['_等级'].value_counts().to_dict())

    print("\n[修补后] 区域分布:")
    print(sampled_local['区域'].value_counts().to_dict())

    sampled_local = sampled_local.drop(columns=['_PMC', '_等级'], errors='ignore')

    return sampled_local, patch_log


def generate_pmc_score_table_sampled_only(
    sampled_local: pd.DataFrame,
    central_selected: pd.Series,
    secondary: Dict,
    weights: Dict[str, float],
    output_dir: str
) -> pd.DataFrame:
    """
    生成表11：仅显示分层抽样的9份政策（1份中央 + 8份地方）
    使用分段评分法-平衡版
    按PMC得分降序排序
    采用 Tab.10 等级标准
    """
    print("\n" + "=" * 70)
    print("生成表11：分层抽样政策的PMC指数得分表（9份政策）")
    print("评分方法：分段评分法-平衡版")
    print("等级标准：Tab.10（优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0）")
    print("排序方式：按PMC得分降序排序")
    print("=" * 70)
    
    results = []
    
    # 1. 处理中央政策
    if not central_selected.empty:
        file_path = central_selected.get('文件路径', '')
        if os.path.exists(file_path):
            content, _ = read_file_with_encoding(file_path)
            if content:
                score = calc_single_pmc_score(content, secondary, weights)
                primary_scores = get_primary_indicator_scores(content, secondary)
                
                row = {
                    "文件名称": central_selected['文件名称'],
                    "类型": "中央",
                    "发布省份": "中央",
                    "区域": "中央",
                    "所属时期": central_selected.get('所属时期', '未知'),
                    "PMC得分": round(score, 2)
                }
                for pid in PRIMARY_KEYS:
                    row[f"X{list(PRIMARY_KEYS).index(pid)+1}"] = round(primary_scores.get(pid, 0), 4)
                results.append(row)
                print(f"   ✅ 中央: {central_selected['文件名称']} | PMC={score:.2f}")
    
    # 2. 处理地方政策
    for idx, row in sampled_local.iterrows():
        file_path = row.get('文件路径', '')
        if os.path.exists(file_path):
            content, _ = read_file_with_encoding(file_path)
            if content:
                score = calc_single_pmc_score(content, secondary, weights)
                primary_scores = get_primary_indicator_scores(content, secondary)
                
                result_row = {
                    "文件名称": row['文件名称'],
                    "类型": "地方",
                    "发布省份": row.get('发布省份', '未知'),
                    "区域": row.get('区域', '未知'),
                    "所属时期": row.get('所属时期', '未知'),
                    "PMC得分": round(score, 2)
                }
                for pid in PRIMARY_KEYS:
                    result_row[f"X{list(PRIMARY_KEYS).index(pid)+1}"] = round(primary_scores.get(pid, 0), 4)
                results.append(result_row)
                print(f"   ✅ 地方: {row['文件名称']} | PMC={score:.2f}")
    
    if len(results) == 0:
        print("   ❌ 未计算出任何政策的PMC得分")
        return pd.DataFrame()
    
    # 3. 构建DataFrame
    table_df = pd.DataFrame(results)
    
    # 4. 按PMC得分降序排序（从高到低）
    table_df = table_df.sort_values('PMC得分', ascending=False).reset_index(drop=True)
    
    # 5. 添加排名列
    table_df.insert(0, "排名", range(1, len(table_df) + 1))
    
    # 6. 添加政策等级（采用 Tab.10 标准）
    table_df["政策等级"] = table_df["PMC得分"].apply(get_pmc_grade)
    
    # 7. 重新排列列顺序
    x_cols = [f"X{i}" for i in range(1, 10)]
    cols = ["排名", "文件名称", "类型", "发布省份", "区域", "所属时期"] + x_cols + ["PMC得分", "政策等级"]
    cols = [c for c in cols if c in table_df.columns]
    table_df = table_df[cols]
    
    # 8. 保存表11（仅CSV和Excel）
    output_path = os.path.join(output_dir, "表11_分层抽样政策PMC指数得分表_分段评分法_Tab10等级_按PMC排序.csv")
    table_df.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"   ✅ 表11保存至: {output_path}")
    
    try:
        excel_path = os.path.join(output_dir, "表11_分层抽样政策PMC指数得分表_分段评分法_Tab10等级_按PMC排序.xlsx")
        table_df.to_excel(excel_path, index=False)
        print(f"   ✅ 表11(Excel)保存至: {excel_path}")
    except Exception as e:
        print(f"   ⚠️ Excel导出失败: {e}")
    
    # 9. 打印表11预览
    print("\n【表11 预览 - 分层抽样9份政策（按PMC得分降序排序）】")
    print("等级标准：Tab.10（优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0）")
    print("-" * 120)
    display_df = table_df.copy()
    for col in x_cols + ["PMC得分"]:
        if col in display_df.columns:
            display_df[col] = display_df[col].apply(lambda x: f"{x:.4f}" if isinstance(x, (int, float)) else x)
    print(display_df.to_string(index=False))
    print("-" * 120)
    
    # 10. 统计摘要
    central_rows = table_df[table_df["类型"] == "中央"]
    local_rows = table_df[table_df["类型"] == "地方"]
    
    print(f"\n【统计摘要】")
    print(f"  中央政策数量: {len(central_rows)}")
    print(f"  地方政策数量: {len(local_rows)}")
    if len(local_rows) > 0:
        print(f"  地方政策PMC均值: {local_rows['PMC得分'].mean():.4f}")
        print(f"  地方政策PMC标准差: {local_rows['PMC得分'].std():.4f}")
    print(f"  最高PMC得分: {table_df['PMC得分'].max():.4f}")
    print(f"  最低PMC得分: {table_df['PMC得分'].min():.4f}")
    
    print(f"\n【等级分布 (Tab.10 标准)】")
    grade_counts = table_df["政策等级"].value_counts()
    total = len(table_df)
    for grade in ["优秀", "良好", "可接受", "不良"]:
        count = grade_counts.get(grade, 0)
        pct = count / total * 100 if total > 0 else 0
        print(f"  {grade} (≥7.0/≥6.0/≥5.0/<5.0): {count} 份 ({pct:.1f}%)")
    
    return table_df


# ==================== 【修改】PMC曲面图绘制模块（横纵坐标互换） ====================
# ==================== 【修改】PMC曲面图绘制模块（横纵坐标互换） ====================
# 【2026-09 调整】
#   1. 曲面图选取逻辑：从表11 中每区域各取 1 个（东北/东部/中部/西部）
#   2. 不再强制等级覆盖，只按"区域 + PMC 最高"选
#   3. 曲面图完全来自表11（分层抽样结果）

def plot_pmc_surface(region_name, scores, ax=None):
    """
    绘制单个地区的PMC曲面图（横纵坐标互换版本）
    """
    # 构建PMC矩阵 (3x3) 并进行转置以实现横纵坐标互换
    pmc_matrix = np.array(scores).reshape(3, 3).T

    # 创建网格
    x = np.arange(3)
    y = np.arange(3)
    x_grid, y_grid = np.meshgrid(x, y)

    if ax is None:
        fig = plt.figure(figsize=(12, 10))
        ax = fig.add_subplot(111, projection='3d')

    # 绘制曲面
    surf = ax.plot_surface(
        x_grid, y_grid, pmc_matrix,
        cmap=cm.RdYlGn,
        alpha=0.9,
        linewidth=1,
        antialiased=True,
        edgecolor='gray'
    )

    # 坐标轴刻度标签
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(['X1', 'X2', 'X3'], fontsize=21)
    ax.set_yticks([0, 1, 2])
    ax.set_yticklabels(['X1-X3', 'X4-X6', 'X7-X9'], fontsize=21)

    # 坐标轴标签
    ax.set_xlabel('Primary Variable (Column)', fontsize=23, labelpad=15)
    ax.set_ylabel('Primary Variable (Row)', fontsize=23, labelpad=15)
    ax.set_zlabel('Score', fontsize=23, labelpad=15)

    # 设置z轴范围
    ax.set_zlim(0, 1)

    # 子图标题
    ax.set_title(f'{region_name}', fontsize=25, fontweight='bold', pad=20)

    # 颜色条
    mappable = cm.ScalarMappable(cmap=cm.RdYlGn)
    mappable.set_array(pmc_matrix)
    cbar = plt.colorbar(
        mappable, ax=ax,
        shrink=0.6, aspect=15,
        pad=0.15, fraction=0.05
    )
    cbar.set_label('Score (0-1)', fontsize=23)
    cbar.ax.tick_params(labelsize=19)

    return ax


def generate_pmc_surface_charts(
    table11_df: pd.DataFrame,
    output_dir: str,
    selected_regions: List[str] = None
) -> Dict[str, str]:
    """
    从表11数据生成PMC曲面图
    【选取逻辑】
      - 从表11 中，每区域各取 1 个（东北/东部/中部/西部）
      - 每区域内取 PMC 最高的那一份
      - 不再强制等级覆盖
      - 中央政策单独 1 张
    """
    print("\n" + "=" * 70)
    print("Generating PMC Surface Charts (Based on Table 11)")
    print("=" * 70)
    print("Selection Criteria:")
    print("  1. From Table 11 only (stratified sampling result)")
    print("  2. One representative per region (Northeast / East / Central / West)")
    print("  3. Within each region, pick the highest PMC policy")
    print("  4. Central policy is plotted separately")

    setup_chinese_font()

    if table11_df is None or len(table11_df) == 0:
        print("   [X] Table 11 is empty, cannot generate surface charts")
        return {}

    x_cols = [f"X{i}" for i in range(1, 10)]
    available_cols = [c for c in x_cols if c in table11_df.columns]

    if len(available_cols) < 9:
        print(f"   [X] Missing required X1-X9 columns: {table11_df.columns.tolist()}")
        return {}

    score_df = table11_df[["文件名称", "类型", "发布省份", "区域", "政策等级", "PMC得分"] + available_cols].copy()

    if "区域" not in score_df.columns:
        region_map = {
            '北京': '东部', '天津': '东部', '河北': '东部', '上海': '东部',
            '江苏': '东部', '浙江': '东部', '福建': '东部', '山东': '东部',
            '广东': '东部', '海南': '东部',
            '山西': '中部', '安徽': '中部', '江西': '中部', '河南': '中部',
            '湖北': '中部', '湖南': '中部',
            '内蒙古': '西部', '广西': '西部', '重庆': '西部', '四川': '西部',
            '贵州': '西部', '云南': '西部', '西藏': '西部', '陕西': '西部',
            '甘肃': '西部', '青海': '西部', '宁夏': '西部', '新疆': '西部',
            '辽宁': '东北', '吉林': '东北', '黑龙江': '东北'
        }
        score_df['区域'] = score_df['发布省份'].map(lambda x: region_map.get(x, '未知'))

    def get_display_name(row):
        if row['类型'] == '中央':
            return 'Central'
        name_str = str(row['文件名称']).replace('地方_', '').replace('.txt', '')
        for province in ALL_PROVINCES:
            if province in name_str:
                return PROVINCE_EN.get(province, province)
        if row.get('发布省份', '') != '未知':
            return PROVINCE_EN.get(row['发布省份'], row['发布省份'])
        return name_str[:6] if len(name_str) > 6 else name_str

    score_df['显示名称'] = score_df.apply(get_display_name, axis=1)

    print(f"\n   Available policies in Table 11: {len(score_df)}")
    print(f"   Grade distribution: {score_df['政策等级'].value_counts().to_dict()}")
    print(f"   Region distribution: {score_df['区域'].value_counts().to_dict()}")

    output_files = {}

    # ---- 1. 选取中央政策 ----
    central_df = score_df[score_df['类型'] == '中央'].copy()
    if len(central_df) > 0:
        central_selected = central_df.iloc[0]
        print(f"\n   [OK] Central policy: {central_selected['显示名称']} "
              f"(PMC={central_selected['PMC得分']:.2f}, "
              f"{GRADE_EN.get(central_selected['政策等级'], central_selected['政策等级'])})")
    else:
        print("   [!] No central policy data")
        central_selected = None

    # ---- 2. 每区域各选 1 个（从表11 中取，每区域取 PMC 最高的 1 份） ----
    print("\n   Selecting one representative per region from Table 11:")

    local_score_df = score_df[score_df['类型'] == '地方'].copy()

    four_regions = ['东北', '东部', '中部', '西部']
    local_selected = []
    used_provinces = set()

    for region in four_regions:
        region_df = local_score_df[local_score_df['区域'] == region].copy()

        if len(region_df) == 0:
            print(f"      [!] 表11 中 {REGION_EN.get(region, region)} 无地方政策，跳过")
            continue

        # 该区域内 PMC 最高的 1 份
        region_df = region_df.sort_values('PMC得分', ascending=False)
        selected = region_df.iloc[0]

        local_selected.append(selected)
        used_provinces.add(selected['显示名称'])

        print(f"      [OK] {REGION_EN.get(region, region)}: "
              f"{selected['显示名称']} | PMC={selected['PMC得分']:.2f} "
              f"| {GRADE_EN.get(selected['政策等级'], selected['政策等级'])}")

    # 若某区域在表11 中缺失，从其余地方按 PMC 补足到 4 个
    if len(local_selected) < 4:
        print("\n   [!] 部分区域在表11 中缺失，从表11 其余地方按 PMC 补足:")
        remaining = local_score_df[~local_score_df['显示名称'].isin(used_provinces)]
        remaining = remaining.sort_values('PMC得分', ascending=False)
        for idx, row in remaining.iterrows():
            if len(local_selected) >= 4:
                break
            local_selected.append(row)
            used_provinces.add(row['显示名称'])
            print(f"      [OK] 补足: {row['显示名称']} "
                  f"({REGION_EN.get(row['区域'], row['区域'])}) "
                  f"| PMC={row['PMC得分']:.2f}")

    # ---- 3. 合并选取结果 ----
    all_selected = []
    if central_selected is not None:
        all_selected.append(central_selected)

    local_selected = local_selected[:4]
    all_selected.extend(local_selected)

    print("\n" + "=" * 60)
    print(f"Final selection (total {len(all_selected)})")
    print("=" * 60)
    for idx, row in enumerate(all_selected, 1):
        if row['类型'] == '中央':
            tag = "[Central]"
        else:
            tag = f"[{REGION_EN.get(row['区域'], row['区域'])}]"
        print(f"  {idx}. {tag} {row['显示名称']} | "
              f"PMC={row['PMC得分']:.2f} | "
              f"{GRADE_EN.get(row['政策等级'], row['政策等级'])}")

    # 等级分布打印（不再强制覆盖）
    print("\n   Grade distribution in selected policies:")
    grades_in_selected = Counter(row['政策等级'] for row in all_selected)
    for grade, cnt in grades_in_selected.items():
        print(f"      {grade}: {cnt} 份")

    print("\n   Region coverage:")
    regions_in_selected = set(row['区域'] for row in all_selected if row['类型'] != '中央')
    for region in four_regions:
        status = "[OK]" if region in regions_in_selected else "[--]"
        print(f"      {status} {REGION_EN.get(region, region)}")

    # ---- 4. 生成曲面图 ----
    print("\n   Generating PMC surface charts:")

    if len(all_selected) < 2:
        print("   [!] Less than 2 policies selected, cannot generate comparison chart")
        return output_files

    # ---- 4.1 合并对比图 ----
    local_only = [row for row in all_selected if row['类型'] != '中央']
    local_only = local_only[:4]

    if len(local_only) > 0:
        print(f"\n   Combined chart shows {len(local_only)} local provinces:")
        for r in local_only:
            print(f"      - {r['显示名称']} ({REGION_EN.get(r['区域'], r['区域'])}) | "
                  f"PMC={r['PMC得分']:.2f} | "
                  f"{GRADE_EN.get(r['政策等级'], r['政策等级'])}")

        n_policies = len(local_only)
        n_cols = 2
        n_rows = (n_policies + n_cols - 1) // n_cols
        if n_rows < 2:
            n_rows = 2

        fig = plt.figure(figsize=(26, 22))
        valid_local = []

        for idx, row in enumerate(local_only, 1):
            scores = [float(row[f'X{i}']) for i in range(1, 10)]

            calc_pmc = sum(scores) / 9 * 10
            actual_pmc = row['PMC得分']
            if abs(calc_pmc - actual_pmc) > 0.01:
                print(f"   [!] Warning: {row['显示名称']} calcPMC={calc_pmc:.2f}, "
                      f"tablePMC={actual_pmc:.2f}")

            ax = fig.add_subplot(n_rows, n_cols, idx, projection='3d')

            display_name = f"{row['显示名称']}"
            plot_pmc_surface(display_name, scores, ax)
            valid_local.append(row['文件名称'])

        if len(valid_local) > 0:
            plt.subplots_adjust(
                left=0.02, right=0.90,
                bottom=0.05, top=0.95,
                wspace=0.25, hspace=0.15
            )

            combined_path = os.path.join(output_dir, 'PMC曲面图_地方四合一_真实数据.png')
            plt.savefig(combined_path, dpi=1000, bbox_inches='tight', facecolor='white')
            plt.close()
            output_files['combined'] = combined_path
            print(f"   [OK] Combined surface chart saved: {combined_path}")
    else:
        print("   [!] No local policy data, skip combined chart")

    # ---- 4.2 单独绘制 ----
    print(f"\n   Drawing individual charts:")

    for idx, row in enumerate(all_selected):
        scores = [float(row[f'X{i}']) for i in range(1, 10)]

        fig = plt.figure(figsize=(12, 10))
        ax = fig.add_subplot(111, projection='3d')

        if row['类型'] == '中央':
            display_name = "Central"
            safe_name = 'Central'
        else:
            display_name = f"{row['显示名称']}"
            safe_name = f"{REGION_EN.get(row['区域'], row['区域'])}_{row['显示名称']}"

        plot_pmc_surface(display_name, scores, ax)

        plt.tight_layout()
        plt.subplots_adjust(left=0.08, right=0.88, bottom=0.08, top=0.92)

        single_path = os.path.join(output_dir, f'PMC曲面图_{safe_name}_真实数据.png')
        plt.savefig(single_path, dpi=1000, bbox_inches='tight', facecolor='white')
        plt.close()
        output_files[f'single_{row["文件名称"]}'] = single_path
        print(f"   [OK] Individual chart saved: {single_path}")

    # ---- 4.3 输出矩阵 ----
    print("\n" + "=" * 60)
    print("PMC matrices of selected regions (3x3):")
    print("=" * 60)
    for idx, row in enumerate(all_selected):
        scores = [float(row[f'X{i}']) for i in range(1, 10)]
        pmc_matrix = np.array(scores).reshape(3, 3)
        calc_pmc = sum(scores) / 9 * 10
        print(f"\n[{row['显示名称']}] PMC matrix:")
        print(pmc_matrix.round(4))
        print(f"   PMC index: {calc_pmc:.2f} (Table 11: {row['PMC得分']:.2f}) | "
              f"Grade: {GRADE_EN.get(row['政策等级'], row['政策等级'])} | "
              f"Region: {REGION_EN.get(row['区域'], row['区域'])}")

    return output_files

# ==================== 【新增】函数：生成31省份发文数与主题数分组柱状图 ====================

def generate_province_doc_topic_barplot(
    local_lda_results: Dict,
    local_docs: List[str],
    local_files: List[str],
    output_dir: str
) -> Dict[str, str]:
    """
    生成31省份政策发文数与主题数分布的分组柱状图
    【修改】X/Y 轴标签 25 加粗，其他字体按 1.25 倍放大并加粗
    """
    print("\n" + "=" * 70)
    print("Generating Province Document/Topic Distribution Barplot")
    print("Topic count uses hard clustering: each document assigned to 1 topic")
    print("=" * 70)

    output_files = {}

    if local_lda_results is None:
        print("   [X] LDA results empty, cannot generate barplot")
        return output_files

    doc_topic_matrix = local_lda_results.get('doc_topic_matrix')
    if doc_topic_matrix is None:
        print("   [X] Document-topic matrix not found")
        return output_files

    n_topics = local_lda_results['best_k']

    # 获取每个文档的省份
    doc_provinces = []
    for filename in local_files:
        province = extract_province_from_filename(filename)
        if province == "未知":
            for p in ALL_PROVINCES:
                if p in filename:
                    province = p
                    break
        doc_provinces.append(province)

    # 各省份发文数
    province_doc_counts = {}
    for province in ALL_PROVINCES:
        count = sum(1 for p in doc_provinces if p == province)
        province_doc_counts[province] = count

    # 硬聚类
    doc_dominant_topics = []
    for idx in range(len(local_docs)):
        topic_probs = doc_topic_matrix.iloc[idx].values
        dominant_topic_idx = np.argmax(topic_probs)
        doc_dominant_topics.append(dominant_topic_idx)

    # 各省份主题数
    province_topic_counts = {}
    for province in ALL_PROVINCES:
        province_indices = [i for i, p in enumerate(doc_provinces) if p == province]
        if len(province_indices) == 0:
            province_topic_counts[province] = 0
        else:
            unique_topics = set(doc_dominant_topics[i] for i in province_indices)
            province_topic_counts[province] = len(unique_topics)

    # 构建DataFrame
    df = pd.DataFrame({
        '省份': ALL_PROVINCES,
        '发文数': [province_doc_counts.get(p, 0) for p in ALL_PROVINCES],
        '主题数(硬聚类)': [province_topic_counts.get(p, 0) for p in ALL_PROVINCES]
    })

    df['区域'] = df['省份'].map(lambda x: PROVINCE_REGION_MAP.get(x, '未知'))

    csv_path = os.path.join(output_dir, '31省份发文数与主题数_硬聚类.csv')
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"   [OK] Data saved: {csv_path}")

    # ---- 绘制分组柱状图 ----
    region_order = ['东北', '东部', '中部', '西部']
    province_order = []
    for region in region_order:
        region_provinces = df[df['区域'] == region]['省份'].tolist()
        region_provinces_sorted = sorted(
            region_provinces,
            key=lambda x: df[df['省份'] == x]['发文数'].values[0],
            reverse=True
        )
        province_order.extend(region_provinces_sorted)

    df_plot = df.set_index('省份').loc[province_order]

    doc_counts = df_plot['发文数'].values
    topic_counts = df_plot['主题数(硬聚类)'].values
    provinces = df_plot.index.tolist()

    # 【修改】画布同步放大
    fig, ax = plt.subplots(figsize=(30, 15))
    x = np.arange(len(provinces))
    width = 0.35

    bars1 = ax.bar(x - width/2, doc_counts, width,
                   label='Number of Documents',
                   color='#4A90D9', edgecolor='white', linewidth=0.5)
    bars2 = ax.bar(x + width/2, topic_counts, width,
                   label='Number of Topics (Hard Clustering)',
                   color='#E67E22', edgecolor='white', linewidth=0.5)

    # 柱上数值 —— 原 13 → 16 加粗
    for bar, val in zip(bars1, doc_counts):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    str(val), ha='center', va='bottom',
                    fontsize=16, fontweight='bold')

    for bar, val in zip(bars2, topic_counts):
        if val > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    str(val), ha='center', va='bottom',
                    fontsize=16, fontweight='bold', color='#E67E22')

    # X/Y 轴标签 —— 25 加粗（最大字号）
    ax.set_xlabel('Province / Autonomous Region / Municipality',
                  fontsize=25, fontweight='bold')
    ax.set_ylabel('Count', fontsize=25, fontweight='bold')

    # X轴省份刻度 —— 原 15 → 19 加粗
    ax.set_xticks(x)
    ax.set_xticklabels(
        [PROVINCE_EN.get(p, p) for p in provinces],
        rotation=45, ha='right', fontsize=19, fontweight='bold'
    )

    # 图例 —— 原 17 → 21 加粗
    #ax.legend(loc='upper right', fontsize=21, framealpha=0.9,
    #          prop={'weight': 'bold', 'size': 21})

    # Y轴刻度 —— 原 15 → 19 加粗
    ax.tick_params(axis='y', labelsize=19)
    for label in ax.get_yticklabels():
        label.set_fontweight('bold')

    ax.grid(axis='y', linestyle='--', alpha=0.3)
    ax.set_axisbelow(True)

    # 区域分隔线
    region_boundaries = []
    current_region = None
    for i, province in enumerate(provinces):
        region = df_plot.loc[province, '区域']
        if current_region is None:
            current_region = region
        elif region != current_region:
            region_boundaries.append(i - 0.5)
            current_region = region

    for boundary in region_boundaries:
        ax.axvline(x=boundary, color='black', linestyle='-', linewidth=1.5, alpha=0.7)

    # 区域标签 —— 原 16 → 20 加粗
    region_positions = {}
    current_region = None
    region_start = 0
    for i, province in enumerate(provinces):
        region = df_plot.loc[province, '区域']
        if current_region is None:
            current_region = region
            region_start = i
        elif region != current_region:
            region_positions[current_region] = (region_start + i - 1) / 2
            current_region = region
            region_start = i
    region_positions[current_region] = (region_start + len(provinces) - 1) / 2

    for region, pos in region_positions.items():
        ax.text(pos, ax.get_ylim()[1] * 1.02,
                REGION_EN.get(region, region),
                fontsize=20, fontweight='bold', ha='center', va='bottom',
                color='blue')

    y_max = max(max(doc_counts), max(topic_counts)) * 1.15
    ax.set_ylim(0, y_max)

    plt.tight_layout()
    barplot_path = os.path.join(output_dir, '31省份政策发文数与主题数分布_分组柱状图.png')
    plt.savefig(barplot_path, dpi=1000, bbox_inches='tight', facecolor='white')
    plt.close()
    output_files['barplot'] = barplot_path
    print(f"   [OK] Barplot saved: {barplot_path}")

    return output_files


# ==================== 【修改】函数：生成各省份政策文档-主题分布表（硬聚类） ====================

def generate_province_document_topic_table_hard_clustering(
    local_lda_results: Dict,
    local_docs: List[str],
    local_files: List[str],
    output_dir: str
) -> pd.DataFrame:
    """
    生成各省份政策文档-主题分布表（硬聚类）
    每行显示一个省份下每份政策文档的主题分配
    输出列：序号、地区、政策名称、主题
    """
    print("\n" + "=" * 70)
    print("生成各省份政策文档-主题分布表（硬聚类）")
    print("每份文档只分配给概率最高的1个主题")
    print("输出列：序号、地区、政策名称、主题")
    print("=" * 70)
    
    if local_lda_results is None:
        print("   ❌ LDA结果为空")
        return pd.DataFrame()
    
    doc_topic_matrix = local_lda_results.get('doc_topic_matrix')
    if doc_topic_matrix is None:
        print("   ❌ 文档-主题矩阵不存在")
        return pd.DataFrame()
    
    n_topics = local_lda_results['best_k']
    topic_names = local_lda_results['topic_names']
    
    # 获取每个文档的省份信息和主题（硬聚类）
    results = []
    
    for idx, filename in enumerate(local_files):
        province = extract_province_from_filename(filename)
        if province == "未知":
            for p in ALL_PROVINCES:
                if p in filename:
                    province = p
                    break
        
        # 获取该文档的主题概率分布
        topic_probs = doc_topic_matrix.iloc[idx].values
        
        # 硬聚类：取概率最高的主题
        dominant_topic_idx = np.argmax(topic_probs)
        dominant_prob = topic_probs[dominant_topic_idx]
        
        # 构建行数据 - 只保留四列
        row = {
            '序号': idx + 1,
            '地区': province,
            '政策名称': filename.replace('.txt', ''),
            '主题': f"L{dominant_topic_idx + 1}"
        }
        
        results.append(row)
    
    df = pd.DataFrame(results)
    
    # 按省份排序
    df = df.sort_values(['地区', '序号']).reset_index(drop=True)
    
    # 重新生成序号
    df['序号'] = range(1, len(df) + 1)
    
    # 只保留指定的四列
    df = df[['序号', '地区', '政策名称', '主题']]
    
    # 保存CSV
    output_path = os.path.join(output_dir, '各省份政策文档-主题分布表_硬聚类.csv')
    df.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"   ✅ 各省份政策文档-主题分布表已保存: {output_path}")
    
    # 打印预览
    print("\n【各省份政策文档-主题分布表预览（前15行）】")
    print("-" * 80)
    print(df.head(15).to_string(index=False, max_colwidth=25))
    if len(df) > 15:
        print(f"   ... 共 {len(df)} 份文档")
    print("-" * 80)
    
    # 统计各省份文档数
    province_doc_counts = df['地区'].value_counts().sort_index()
    print("\n【各省份文档数统计】")
    print("-" * 40)
    for province, count in province_doc_counts.items():
        print(f"   {province}: {count} 份文档")
    print("-" * 40)
    
    # 统计各主题文档数
    topic_doc_counts = df['主题'].value_counts().sort_index()
    print("\n【各主题文档数统计】")
    print("-" * 40)
    for topic, count in topic_doc_counts.items():
        print(f"   {topic}: {count} 份文档")
    print("-" * 40)
    
    return df


# ==================== 【新增】函数：生成中央政策文档-主题分布表（硬聚类） ====================

def generate_central_document_topic_table(
    central_lda_results: Dict,
    central_docs: List[str],
    central_files: List[str],
    output_dir: str
) -> pd.DataFrame:
    """
    生成中央政策的"文档-主题"分布表（硬聚类）
    每个文档只分配给概率最高的1个主题
    """
    print("\n" + "=" * 70)
    print("生成中央政策'文档-主题'分布表（硬聚类）")
    print("=" * 70)
    
    if central_lda_results is None:
        print("   ❌ 中央LDA结果为空")
        return pd.DataFrame()
    
    doc_topic_matrix = central_lda_results.get('doc_topic_matrix')
    if doc_topic_matrix is None:
        print("   ❌ 文档-主题矩阵不存在")
        return pd.DataFrame()
    
    results = []
    for idx, (doc, filename) in enumerate(zip(central_docs, central_files)):
        topic_probs = doc_topic_matrix.iloc[idx].values
        dominant_topic_idx = np.argmax(topic_probs)
        dominant_prob = topic_probs[dominant_topic_idx]
        
        dominant_topic = f"C{dominant_topic_idx + 1}"
        
        policy_name = filename.replace('.txt', '')
        if len(policy_name) > 40:
            policy_name = policy_name[:37] + "..."
        
        results.append({
            "序号": idx + 1,
            "地区": "中央",
            "政策名称": policy_name,
            "主题": dominant_topic,
            "主题概率": round(dominant_prob, 3)
        })
    
    df = pd.DataFrame(results)
    
    output_path = os.path.join(output_dir, '中央政策文档-主题分布表_硬聚类.csv')
    df[['序号', '地区', '政策名称', '主题']].to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"   ✅ 中央政策文档-主题分布表已保存: {output_path}")
    
    print("\n【中央政策文档-主题分布表预览】")
    print("-" * 100)
    print(df[['序号', '地区', '政策名称', '主题']].to_string(index=False, max_colwidth=35))
    print("-" * 100)
    
    # 统计主题分布
    topic_distribution = df['主题'].value_counts().sort_index()
    print("\n【中央政策主题分布统计】")
    print("-" * 40)
    for topic, count in topic_distribution.items():
        print(f"   {topic}: {count} 篇文档")
    print("-" * 40)
    
    return df


# ==================== 【修改】综合报告 - 主题格式 C1, C2, C3... 和 L1, L2, L3... ====================

def generate_complete_chinese_report(
    central_lda_results, local_lda_results, 
    similarity_stats, topic_similarity_df,
    score_stats, weights_df, cluster_res,
    delphi_stats_df, expert_count,
    central_mean, local_mean,
    central_std, local_std,
    table5_df: Optional[pd.DataFrame] = None,
    table6_df: Optional[pd.DataFrame] = None,
    table7_df: Optional[pd.DataFrame] = None,
    pmc_indicator_df: Optional[pd.DataFrame] = None,
    match_threshold: float = 0.55,
    match_mode: str = 'doc_ratio',
    sampled_local: Optional[pd.DataFrame] = None,
    central_selected: Optional[pd.Series] = None,
    table11_df: Optional[pd.DataFrame] = None,
    surface_files: Optional[Dict] = None,
    barplot_files: Optional[Dict] = None,
    province_doc_topic_df: Optional[pd.DataFrame] = None,  # 【新增】
    central_doc_topic_df: Optional[pd.DataFrame] = None
) -> str:
    
    central_pmc_mean = score_stats['central_mean']
    central_pmc_ci_lower = score_stats['central_ci_lower']
    central_pmc_ci_upper = score_stats['central_ci_upper']
    local_pmc_mean = score_stats['local_mean']
    local_pmc_ci_lower = score_stats['local_ci_lower']
    local_pmc_ci_upper = score_stats['local_ci_upper']
    central_pmc_std = score_stats['central_std']
    local_pmc_std = score_stats['local_std']
    t_stat = score_stats['t_statistic']
    p_value = score_stats['p_value']
    effect_size = score_stats['effect_size']
    central_count = score_stats['central_count']
    local_count = score_stats['local_count']
    
    is_significant = p_value < 0.05
    significance_statement = f"t={t_stat:.4f}, p={p_value:.4f}（{'p<0.05，差异显著' if is_significant else 'p>0.05，差异不显著'}）"
    
    if effect_size < 0.2:
        effect_statement = "效应量极小（Cohen's d < 0.2）"
    elif effect_size < 0.5:
        effect_statement = "效应量较小（Cohen's d < 0.5）"
    elif effect_size < 0.8:
        effect_statement = "效应量中等（Cohen's d < 0.8）"
    else:
        effect_statement = "效应量大（Cohen's d ≥ 0.8）"
    
    central_topic_count = central_lda_results['best_k'] if central_lda_results else 0
    local_topic_count = local_lda_results['best_k'] if local_lda_results else 0
    
    # 【修改】中央主题按 C1, C2, C3... 格式输出，显示全部主题
    central_topic_names_list = []
    if central_lda_results:
        for i in range(len(central_lda_results['topic_words'])):
            top_8_words = central_lda_results['topic_words'][i][:8]
            topic_str = f"C{i+1}: {', '.join(top_8_words)}"
            central_topic_names_list.append(topic_str)
    central_topic_names_str = "\n    ".join(central_topic_names_list) if central_topic_names_list else "无"
    
    # 【修改】地方主题按 L1, L2, L3... 格式输出，显示全部主题
    local_topic_names_list = []
    if local_lda_results:
        n_topics = len(local_lda_results['topic_words'])
        for i in range(n_topics):
            top_8_words = local_lda_results['topic_words'][i][:8]
            topic_str = f"L{i+1}: {', '.join(top_8_words)}"
            local_topic_names_list.append(topic_str)
    local_topic_names_str = "\n    ".join(local_topic_names_list) if local_topic_names_list else "无"
    
    doc2vec_mean = similarity_stats['mean_similarity'] if similarity_stats else 0
    topic_sim_mean = topic_similarity_df.values.mean() if topic_similarity_df is not None else 0
    
    report_lines = []
    report_lines.append("=" * 90)
    report_lines.append("青少年体育训练政策综合分析报告")
    report_lines.append("=" * 90)
    report_lines.append(f"报告生成时间：{pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append(f"随机种子：{RANDOM_SEED}")
    report_lines.append("")
    report_lines.append("【分析方法】")
    report_lines.append("  - LDA主题模型：使用困惑度确定最佳主题数")
    report_lines.append("  - Doc2Vec文本相似度：计算央地政策文本相似度")
    report_lines.append("  - PMC指数评价：分段评分法-平衡版")
    report_lines.append("  - 等级标准：Tab.10（优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0）")
    report_lines.append("  - 一级指标数量：9个（已删除X10央地一致性）")
    report_lines.append("  - 权重方案：等权重（每个一级指标权重 = 11.11%）")
    report_lines.append("  - Bootstrap置信区间：1000次重采样，95%置信水平")
    report_lines.append("  - 统计检验：独立样本t检验，Cohen's d效应量")
    if table5_df is not None:
        report_lines.append(f"  - 表5改进 v4：匹配模式={match_mode}，阈值={match_threshold}")
    if table7_df is not None:
        report_lines.append(f"  - 表7：Doc2Vec文本相似度，dm={DOC2VEC_PARAMS['dm']}, window={DOC2VEC_PARAMS['window']}, size={DOC2VEC_PARAMS['vector_size']}, workers=1（可复现模式）")
    report_lines.append("  - PMC曲面图：基于真实政策数据的3D可视化分析（横纵坐标已互换）")
    report_lines.append("  - 31省份发文数与主题数分组柱状图：基于硬聚类结果")
    report_lines.append("  - 各省份主题分布统计：各省份在各LDA主题上的文档数")
    report_lines.append("  - 中央政策文档-主题分布表：中央政策文档的主题分配（硬聚类）")
    report_lines.append("")
    
    # 分层抽样结果摘要
    if sampled_local is not None and len(sampled_local) > 0:
        report_lines.append("=" * 90)
        report_lines.append("【分层抽样结果】")
        report_lines.append("-" * 40)
        report_lines.append(f"省级政策样本：{len(sampled_local)}项")
        report_lines.append("区域分布：")
        for region, count in sampled_local['区域'].value_counts().sort_index().items():
            report_lines.append(f"  {region}：{count}项")
        report_lines.append("时期分布：")
        for period, count in sampled_local['所属时期'].value_counts().sort_index().items():
            report_lines.append(f"  {period}：{count}项")
        report_lines.append("")
        report_lines.append("抽样省份列表：")
        for idx, row in sampled_local.iterrows():
            report_lines.append(f"  {row['发布省份']}：{row['文件名称']} ({row['所属时期']})")
        report_lines.append("")
        if central_selected is not None and not central_selected.empty:
            report_lines.append(f"中央政策样本：{central_selected['文件名称']} ({central_selected['所属时期']})")
            report_lines.append("")
    
    # 一、数据概况
    report_lines.append("=" * 90)
    report_lines.append("一、数据概况")
    report_lines.append("-" * 40)
    report_lines.append(f"  中央政策文本：{central_count}份")
    report_lines.append(f"  地方政策文本：{local_count}份")
    # 【修改】更新人民日报语料描述，显示实际采样数量
    report_lines.append(f"  人民日报语料：{PEOPLE_DAILY_CONFIG['max_articles']}篇文章（1946-2003年）")
    report_lines.append(f"  权重方案：等权重（共{len(PRIMARY_KEYS)}个一级指标，每个权重11.11%）")
    if table5_df is not None:
        report_lines.append(f"  覆盖省份：{len(table5_df)}个")
    if table6_df is not None:
        report_lines.append(f"  覆盖区域：4大区域（东部、中部、西部、东北）")
    if table7_df is not None:
        report_lines.append(f"  文本相似度覆盖：{len(table7_df[table7_df['政策数']>0])}个省份")
    report_lines.append("")
    
    # 二、PMC指标体系
    if pmc_indicator_df is not None:
        report_lines.append("=" * 90)
        report_lines.append("二、青少年体育央地政策PMC指数模型评价指标体系（9个一级指标）")
        report_lines.append("-" * 40)
        report_lines.append("")
        report_lines.append("| 一级指标 | 一级指标描述 | 二级指标 | 评价标准 | 关键词 | 参考文献 |")
        report_lines.append("|----------|--------------|----------|----------|--------|----------|")
        for idx, row in pmc_indicator_df.iterrows():
            keywords_short = row['关键词'] if len(row['关键词']) <= 20 else row['关键词'][:20] + "..."
            ref_short = row['参考文献'] if len(row['参考文献']) <= 15 else row['参考文献'][:15] + "..."
            report_lines.append(f"| {row['一级指标代码']} {row['一级指标名称']} | {row['一级指标描述']} | {row['二级指标代码']} {row['二级指标名称']} | {row['评价标准']} | {keywords_short} | {ref_short} |")
        report_lines.append("")
        report_lines.append("完整指标体系请参见：`PMC_指标体系_完整表.csv`")
        report_lines.append("")
    
    # 三、LDA主题分析结果
    report_lines.append("=" * 90)
    report_lines.append("三、LDA主题模型分析结果")
    report_lines.append("-" * 40)
    if central_lda_results:
        report_lines.append(f"  中央政策最佳主题数：{central_lda_results['best_k']}")
        report_lines.append(f"  中央政策最小困惑度：{min(central_lda_results['perplexities']):.2f}")
        report_lines.append(f"  中央政策主题（Top 8关键词）：")
        report_lines.append(f"    {central_topic_names_str}")
    if local_lda_results:
        report_lines.append(f"  地方政策最佳主题数：{local_lda_results['best_k']}")
        report_lines.append(f"  地方政策最小困惑度：{min(local_lda_results['perplexities']):.2f}")
        report_lines.append(f"  地方政策主题（Top 8关键词）：")
        report_lines.append(f"    {local_topic_names_str}")
    report_lines.append("")
    
    # 四、Doc2Vec文本相似度（句子级）
    if similarity_stats:
        report_lines.append("=" * 90)
        report_lines.append("四、央地政策文本相似度分析（Doc2Vec句子级）")
        report_lines.append("-" * 40)
        report_lines.append(f"  中央句子数：{similarity_stats['central_sentence_count']}")
        report_lines.append(f"  地方句子数：{similarity_stats['local_sentence_count']}")
        report_lines.append(f"  平均相似度：{similarity_stats['mean_similarity']:.4f}")
        report_lines.append(f"  中位相似度：{similarity_stats['median_similarity']:.4f}")
        report_lines.append(f"  标准差：{similarity_stats['std_similarity']:.4f}")
        report_lines.append(f"  相似度范围：[{similarity_stats['min_similarity']:.4f}, {similarity_stats['max_similarity']:.4f}]")
        report_lines.append("")
    
    # 五、主题相似度矩阵
    if topic_similarity_df is not None:
        report_lines.append("=" * 90)
        report_lines.append("五、央地政策主题相似度矩阵")
        report_lines.append("-" * 40)
        report_lines.append(f"  矩阵维度：{topic_similarity_df.shape[0]}个地方主题 × {topic_similarity_df.shape[1]}个中央主题")
        report_lines.append(f"  平均相似度：{topic_similarity_df.values.mean():.4f}")
        report_lines.append(f"  最大相似度：{topic_similarity_df.values.max():.4f}")
        report_lines.append(f"  最小相似度：{topic_similarity_df.values.min():.4f}")
        report_lines.append("")
    
    # 六、表5结果
    if table5_df is not None and len(table5_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("六、表5 各省主题承继比、扩散比、协同度分析")
        report_lines.append("-" * 40)
        report_lines.append(f"  覆盖省份：{len(table5_df)}个")
        report_lines.append(f"  协同度均值：{table5_df['主题协同度(TR)'].mean():.3f}")
        report_lines.append(f"  协同度中位数：{table5_df['主题协同度(TR)'].median():.3f}")
        report_lines.append(f"  协同度范围：[{table5_df['主题协同度(TR)'].min():.3f}, {table5_df['主题协同度(TR)'].max():.3f}]")
        
        tr_high = len(table5_df[table5_df['主题协同度(TR)'] >= 0.7])
        tr_medium = len(table5_df[(table5_df['主题协同度(TR)'] >= 0.3) & (table5_df['主题协同度(TR)'] < 0.7)])
        tr_low = len(table5_df[(table5_df['主题协同度(TR)'] > 0) & (table5_df['主题协同度(TR)'] < 0.3)])
        tr_zero = len(table5_df[table5_df['主题协同度(TR)'] == 0])
        report_lines.append(f"  协同度分布：高(≥0.7)={tr_high}, 中(0.3-0.7)={tr_medium}, 低(0-0.3)={tr_low}, 零={tr_zero}")
        
        top5 = table5_df.nlargest(5, '主题协同度(TR)')
        report_lines.append(f"  协同度最高5省：")
        for idx, row in top5.iterrows():
            report_lines.append(f"    {row['地区']}: TR={row['主题协同度(TR)']:.3f}")
        report_lines.append("")
    
    # 七、表6结果
    if table6_df is not None and len(table6_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("七、表6 各地区主题承继比、扩散比、协同度汇总")
        report_lines.append("-" * 40)
        # 【修复】使用"区域"列名（与表6保存时一致）
        for idx, row in table6_df.iterrows():
            report_lines.append(f"  {row['区域']}地区：文本数={row['文本数']}, 承继比={row['承继比']:.3f}, 扩散比={row['扩散比']:.3f}, 响应度={row['主题响应度']:.3f}")
        report_lines.append("")
    
    # 八、表7结果
    if table7_df is not None and len(table7_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("八、表7 各省央地文本相似度分析")
        report_lines.append("-" * 40)
        df_valid = table7_df[table7_df['政策数'] > 0]
        report_lines.append(f"  覆盖省份：{len(df_valid)}个")
        if len(df_valid) > 0:
            report_lines.append(f"  相似度均值：{df_valid['最大相似度'].mean():.6f}")
            report_lines.append(f"  相似度中位数：{df_valid['最大相似度'].median():.6f}")
            report_lines.append(f"  相似度范围：[{df_valid['最大相似度'].min():.6f}, {df_valid['最大相似度'].max():.6f}]")
            
            top5 = df_valid.nlargest(5, '最大相似度')
            report_lines.append(f"  相似度最高5省：")
            for idx, row in top5.iterrows():
                report_lines.append(f"    {row['省份']}: {row['最大相似度']:.6f}")
        report_lines.append("")
    
    # 九、PMC指数分析
    report_lines.append("=" * 90)
    report_lines.append("九、PMC指数评价分析（分段评分法-平衡版，9个指标，等权重）")
    report_lines.append("-" * 40)
    report_lines.append(f"  中央政策PMC均值：{central_pmc_mean:.2f} (95% CI: [{central_pmc_ci_lower:.2f}, {central_pmc_ci_upper:.2f}])")
    report_lines.append(f"  地方政策PMC均值：{local_pmc_mean:.2f} (95% CI: [{local_pmc_ci_lower:.2f}, {local_pmc_ci_upper:.2f}])")
    report_lines.append(f"  t检验：{significance_statement}")
    report_lines.append(f"  效应量：{effect_size:.3f} ({effect_statement})")
    report_lines.append("")
    
    # 十、权重说明
    report_lines.append("=" * 90)
    report_lines.append("十、权重配置说明")
    report_lines.append("-" * 40)
    report_lines.append(f"权重方案：等权重")
    report_lines.append(f"一级指标数量：{len(PRIMARY_KEYS)}个（已删除X10央地一致性）")
    report_lines.append(f"每个指标权重：{1.0/len(PRIMARY_KEYS):.4f} ({1.0/len(PRIMARY_KEYS)*100:.1f}%)")
    report_lines.append("")
    report_lines.append("各指标权重列表：")
    for idx, row in weights_df.iterrows():
        report_lines.append(f"  {idx+1}. {row['指标名称']}：{row['权重百分比']}")
    report_lines.append("")
    report_lines.append("说明：已移除德尔菲法，所有一级指标采用等权重方案。")
    report_lines.append("")
    
    # 十一、聚类验证
    if cluster_res:
        report_lines.append("=" * 90)
        report_lines.append("十一、聚类验证")
        report_lines.append("-" * 40)
        report_lines.append(f"  最优聚类数：{cluster_res['best_k']}")
        report_lines.append(f"  轮廓系数：{cluster_res['score']:.3f}")
        report_lines.append(f"  评价等级：{cluster_res['evaluation']}")
        report_lines.append("")
    
    # 十二、表11
    if table11_df is not None and len(table11_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("十二、表11 分层抽样政策PMC指数得分表（1份中央+8份地方）")
        report_lines.append("-" * 40)
        report_lines.append("评分方法：分段评分法-平衡版")
        report_lines.append("等级标准：Tab.10（优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0）")
        report_lines.append("排序方式：按PMC得分从高到低排序")
        report_lines.append("抽样方案：方案A（三时期强制 + 区域配额 + 等级修补）")
        report_lines.append("   - 硬约束1：每省只选1份")
        report_lines.append("   - 硬约束2：十二五、十三五、十四五 各至少1份（强制，缺失时兜底，可打破区域配额）")
        report_lines.append("   - 硬约束3：区域配额 东北1、东部2、中部2、西部3")
        report_lines.append("   - 等级修补：保证 优秀/良好/可接受 全覆盖（不良可选）")
        report_lines.append("")
        report_lines.append("| 排名 | 政策名称 | 类型 | 省份 | 区域 | 时期 | X1 | X2 | X3 | X4 | X5 | X6 | X7 | X8 | X9 | PMC | 等级 |")
        report_lines.append("|------|----------|------|------|------|------|----|----|----|----|----|----|----|----|-----|-----|------|")
        for idx, row in table11_df.iterrows():
            name = str(row["文件名称"])
            if len(name) > 12:
                name = name[:10] + "…"
            x_cols = [f"X{i}" for i in range(1, 10)]
            x_vals = []
            for c in x_cols:
                val = row.get(c, "-")
                if isinstance(val, (int, float)):
                    x_vals.append(f"{val:.2f}")
                else:
                    x_vals.append(str(val))
            pmc = row.get("PMC得分", "-")
            pmc_str = f"{pmc:.2f}" if isinstance(pmc, (int, float)) else str(pmc)
            grade = row.get("政策等级", "-")
            ptype = row.get("类型", "-")
            province = row.get("发布省份", "-")
            region = row.get("区域", "-")
            period = row.get("所属时期", "-")
            report_lines.append(f"| {row['排名']} | {name} | {ptype} | {province} | {region} | {period} | " + " | ".join(x_vals) + f" | {pmc_str} | {grade} |")
        report_lines.append("")
        
        central_rows = table11_df[table11_df["类型"] == "中央"]
        local_rows = table11_df[table11_df["类型"] == "地方"]
        report_lines.append(f"  中央政策数量：{len(central_rows)}")
        report_lines.append(f"  地方政策数量：{len(local_rows)}")
        if len(local_rows) > 0:
            report_lines.append(f"  地方政策PMC均值：{local_rows['PMC得分'].mean():.4f}")
        report_lines.append(f"  最高PMC得分：{table11_df['PMC得分'].max():.4f}")
        report_lines.append(f"  最低PMC得分：{table11_df['PMC得分'].min():.4f}")
        
        grade_counts = table11_df["政策等级"].value_counts()
        report_lines.append("  等级分布 (Tab.10)：")
        for grade in ["优秀", "良好", "可接受", "不良"]:
            count = grade_counts.get(grade, 0)
            pct = count / len(table11_df) * 100 if len(table11_df) > 0 else 0
            report_lines.append(f"    {grade}: {count} ({pct:.1f}%)")
        report_lines.append("")
    
    # 十三、PMC曲面图
    if surface_files:
        report_lines.append("=" * 90)
        report_lines.append("十三、PMC曲面图分析")
        report_lines.append("-" * 40)
        report_lines.append("基于真实政策数据生成的PMC曲面图，展示各一级指标得分的3D分布。")
        report_lines.append("")
        report_lines.append("【横纵坐标说明】")
        report_lines.append("  - X轴（列）：X1、X2、X3（政策级别、政策执行性、政策性质）")
        report_lines.append("  - Y轴（行）：X1-X3、X4-X6、X7-X9（分组显示）")
        report_lines.append("  - Z轴（高度）：各一级指标得分（0-1）")
        report_lines.append("  - 注意：横纵坐标已互换，便于观察不同维度组合的得分分布")
        report_lines.append("")
        report_lines.append("选取标准：")
        report_lines.append("  1. 每区域各取 1 个（东北/东部/中部/西部）")
        report_lines.append("  2. 每区域内取 PMC 最高的一份")
        report_lines.append("  3. 中央政策单独绘制")
        report_lines.append("")
        report_lines.append("【合并图】显示4个地方地区（每区域 PMC 最高）")
        report_lines.append("【单图】显示5个地区（中央 + 4 个地方）")

        report_lines.append("【单图】显示5个地区（包括中央）")
        report_lines.append("")
        report_lines.append("【PMC得分说明】曲面图显示的PMC指数采用与表11相同的计算方法：")
        report_lines.append("  PMC指数 = Σ(一级指标得分) / 9 × 10")
        report_lines.append("")
        if 'combined' in surface_files:
            report_lines.append(f"  合并对比图：{surface_files['combined']}")
        for key, path in surface_files.items():
            if key != 'combined':
                report_lines.append(f"  单图：{path}")
        report_lines.append("")
    
    # 十四、31省份发文数与主题数分布
    if barplot_files and 'barplot' in barplot_files:
        report_lines.append("=" * 90)
        report_lines.append("十四、31省份政策发文数与主题数分布")
        report_lines.append("-" * 40)
        report_lines.append("基于硬聚类结果，每个文档只分配给概率最高的1个主题。")
        report_lines.append("")
        report_lines.append(f"  【分组柱状图】展示31省份的政策发文数和主题数")
        report_lines.append(f"    - 左柱状为发文数（蓝色），右柱状为主题数（橙色）")
        report_lines.append(f"    - 主题数采用硬聚类：每个文档只分配1个主题")
        report_lines.append(f"    - 按区域分组排序（东北、东部、中部、西部）")
        report_lines.append(f"    - 文件路径：{barplot_files['barplot']}")
        report_lines.append("")
    
    # 十五、各省份政策文档-主题分布表
    if province_doc_topic_df is not None and len(province_doc_topic_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("十五、各省份政策文档-主题分布表（硬聚类）")
        report_lines.append("-" * 40)
        report_lines.append("每份地方政策文档只分配给概率最高的1个主题。")
        report_lines.append("")
        report_lines.append("| 序号 | 地区 | 政策名称 | 主题 |")
        report_lines.append("|------|------|----------|------|")
        for idx, row in province_doc_topic_df.head(20).iterrows():
            name = str(row['政策名称'])
            if len(name) > 20:
                name = name[:17] + "..."
            report_lines.append(f"| {row['序号']} | {row['地区']} | {name} | {row['主题']} |")
        if len(province_doc_topic_df) > 20:
            report_lines.append(f"| ... | ... | ... | ... |")
        report_lines.append("")
        report_lines.append(f"完整表格请参见：`各省份政策文档-主题分布表_硬聚类.csv`")
        report_lines.append("")
    
    # 十六、中央政策文档-主题分布表
    if central_doc_topic_df is not None and len(central_doc_topic_df) > 0:
        report_lines.append("=" * 90)
        report_lines.append("十六、中央政策文档-主题分布表（硬聚类）")
        report_lines.append("-" * 40)
        report_lines.append("每个中央政策文档只分配给概率最高的1个主题。")
        report_lines.append("")
        report_lines.append("| 序号 | 地区 | 政策名称 | 主题 |")
        report_lines.append("|------|------|----------|------|")
        for idx, row in central_doc_topic_df.iterrows():
            name = str(row['政策名称'])
            if len(name) > 20:
                name = name[:17] + "..."
            report_lines.append(f"| {row['序号']} | {row['地区']} | {name} | {row['主题']} |")
        report_lines.append("")
        report_lines.append(f"完整表格请参见：`中央政策文档-主题分布表_硬聚类.csv`")
        report_lines.append("")
    
    # 十七、结论
    report_lines.append("=" * 90)
    report_lines.append("十七、主要结论与建议")
    report_lines.append("-" * 40)
    
    if local_pmc_mean < central_pmc_mean:
        diff = central_pmc_mean - local_pmc_mean
        report_lines.append(f"  1. 中央政策PMC指数均值（{central_pmc_mean:.2f}）高于地方政策（{local_pmc_mean:.2f}），差距为{diff:.2f}分。")
    else:
        diff = local_pmc_mean - central_pmc_mean
        report_lines.append(f"  1. 地方政策PMC指数均值（{local_pmc_mean:.2f}）高于中央政策（{central_pmc_mean:.2f}），差距为{diff:.2f}分。")
    
    if is_significant:
        report_lines.append(f"  2. 中央与地方政策质量差异具有统计学意义（t检验，{significance_statement}）。")
    else:
        report_lines.append(f"  2. 中央与地方政策质量差异不具有统计学意义（t检验，{significance_statement}）。")
    
    if effect_size >= 0.5:
        report_lines.append(f"  3. 效应量中等以上（Cohen's d={effect_size:.3f}），差异具有实际意义。")
    
    if table5_df is not None and len(table5_df) > 0:
        avg_tr = table5_df['主题协同度(TR)'].mean()
        if avg_tr >= 0.5:
            report_lines.append(f"  4. 地方政策对中央政策的主题协同度较高（均值={avg_tr:.3f}），央地政策主题一致性较好。")
        else:
            report_lines.append(f"  4. 地方政策对中央政策的主题协同度中等（均值={avg_tr:.3f}），央地政策主题一致性有待加强。")
    
    if table11_df is not None and len(table11_df) > 0:
        good_ratio = len(table11_df[table11_df["政策等级"].isin(["优秀", "良好"])]) / len(table11_df) * 100
        report_lines.append(f"  5. 分层抽样9份政策中，优秀/良好等级占比为{good_ratio:.1f}%，政策整体质量良好。")
    
    report_lines.append("")
    report_lines.append("【建议】")
    report_lines.append("  1. 加强地方政策对中央政策的响应与转化，提升主题协同度。")
    report_lines.append("  2. 完善政策评价与监督机制，提升PMC指数中相关指标得分。")
    report_lines.append("  3. 推动央地政策在训练内容、教练师资、竞赛体系等核心要素上的协同。")
    report_lines.append("  4. 鼓励地方结合自身特色制定差异化政策，避免简单复制中央政策。")
    report_lines.append("")
    
    report_lines.append("=" * 90)
    report_lines.append(f"报告生成完毕。所有结果文件已保存至：{OUTPUT_DIR}")
    report_lines.append("=" * 90)
    
    report_path = os.path.join(OUTPUT_DIR, "青少年体育政策综合分析报告.txt")
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(report_lines))
    print(f"\n✅ Complete Chinese report saved: {report_path}")
    return "\n".join(report_lines)


def save_run_info(
    score_stats, similarity_stats, central_lda_results, local_lda_results,
    table5_df: Optional[pd.DataFrame] = None,
    table6_df: Optional[pd.DataFrame] = None,
    table7_df: Optional[pd.DataFrame] = None,
    match_threshold: float = 0.55,
    match_mode: str = 'doc_ratio',
    sampled_local: Optional[pd.DataFrame] = None,
    central_selected: Optional[pd.Series] = None,
    table11_df: Optional[pd.DataFrame] = None,
    surface_files: Optional[Dict] = None,
    barplot_files: Optional[Dict] = None,
    province_doc_topic_df: Optional[pd.DataFrame] = None,
    central_doc_topic_df: Optional[pd.DataFrame] = None
):
    run_info = {
        'timestamp': datetime.now().isoformat(),
        'random_seed': RANDOM_SEED,
        'weight_scheme': 'equal_weight',
        'primary_indicators': len(PRIMARY_KEYS),
        'weight_description': f'Each of {len(PRIMARY_KEYS)} indicators has equal weight = {1.0/len(PRIMARY_KEYS):.4f}',
        'note': 'X10 (央地一致性) 已删除',
        'scoring_method': '分段评分法-平衡版',
        'grade_standard': 'Tab.10 (优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0)',
        'scoring_rules': {
            '≥80%': 1.0,
            '≥60%': 0.8,
            '≥40%': 0.6,
            '≥20%': 0.4,
            '>0%': 0.25,
            '0%': 0.0
        },
        'people_daily_config': {
            'max_articles': PEOPLE_DAILY_CONFIG['max_articles'],
            'keywords_top_n': PEOPLE_DAILY_CONFIG['keywords_top_n']
        },
        'doc2vec_params': DOC2VEC_PARAMS,
        'table5_config': {
            'match_mode': match_mode,
            'match_threshold': match_threshold
        },
        'stratified_sampling': {
            'total_sample': STRATIFIED_SAMPLE_CONFIG['total_sample'],
            'region_ratio': STRATIFIED_SAMPLE_CONFIG['region_ratio'],
            'periods': STRATIFIED_SAMPLE_CONFIG['periods']
        },
        'score_stats': {
            'central_mean': float(score_stats['central_mean']),
            'central_ci': [float(score_stats['central_ci_lower']), float(score_stats['central_ci_upper'])],
            'local_mean': float(score_stats['local_mean']),
            'local_ci': [float(score_stats['local_ci_lower']), float(score_stats['local_ci_upper'])],
            't_statistic': float(score_stats['t_statistic']),
            'p_value': float(score_stats['p_value']),
            'effect_size': float(score_stats['effect_size'])
        },
        'similarity_stats': {
            'mean': float(similarity_stats['mean_similarity']) if similarity_stats else None,
            'median': float(similarity_stats['median_similarity']) if similarity_stats else None,
            'std': float(similarity_stats['std_similarity']) if similarity_stats else None
        },
        'lda_results': {
            'central_best_k': central_lda_results['best_k'] if central_lda_results else None,
            'local_best_k': local_lda_results['best_k'] if local_lda_results else None
        },
        'pmc_surface_charts': {
            'generated': surface_files is not None and len(surface_files) > 0,
            'file_count': len(surface_files) if surface_files else 0,
            'combined_only_local': True,
            'selection_rule': '每区域各取 1 个（东北/东部/中部/西部），区域内取 PMC 最高',
            'pmc_calculation_method': 'Σ(X1-X9) / 9 × 10 (与表11一致)',
            'axis_swapped': True
        },

        'province_topic_visualization': {
            'barplot_generated': barplot_files is not None and len(barplot_files) > 0,
            'province_doc_topic_generated': province_doc_topic_df is not None and len(province_doc_topic_df) > 0,
            'central_doc_topic_generated': central_doc_topic_df is not None and len(central_doc_topic_df) > 0,
            'clustering_method': '硬聚类（每个文档只分配1个主题）'
        }
    }
    
    if sampled_local is not None and len(sampled_local) > 0:
        run_info['stratified_sampling']['sampled_provinces'] = sampled_local['发布省份'].tolist()
        run_info['stratified_sampling']['sample_count'] = len(sampled_local)
        run_info['stratified_sampling']['region_distribution'] = sampled_local['区域'].value_counts().to_dict()
        run_info['stratified_sampling']['period_distribution'] = sampled_local['所属时期'].value_counts().to_dict()
    
    if central_selected is not None and not central_selected.empty:
        run_info['stratified_sampling']['selected_central'] = central_selected['文件名称']
    
    if table5_df is not None:
        run_info['table5'] = {
            'province_count': len(table5_df),
            'hscope_mean': float(table5_df['主题承继比(Hscope)'].mean()),
            'dscope_mean': float(table5_df['主题扩散比(Dscope)'].mean()),
            'tr_mean': float(table5_df['主题协同度(TR)'].mean()),
            'tr_median': float(table5_df['主题协同度(TR)'].median()),
            'tr_std': float(table5_df['主题协同度(TR)'].std()),
            'tr_min': float(table5_df['主题协同度(TR)'].min()),
            'tr_max': float(table5_df['主题协同度(TR)'].max())
        }
    
    if table6_df is not None:
        run_info['table6'] = {
            'regions': table6_df['区域'].tolist(),
            'text_counts': table6_df['文本数'].tolist(),
            'topic_counts': table6_df['主题数'].tolist(),
            'hscope': table6_df['承继比'].tolist(),
            'dscope': table6_df['扩散比'].tolist(),
            'tr': table6_df['主题响应度'].tolist()
        }
    
    if table7_df is not None:
        df_valid = table7_df[table7_df['政策数'] > 0]
        run_info['table7'] = {
            'province_count': len(df_valid),
            'similarity_mean': float(df_valid['最大相似度'].mean()) if len(df_valid) > 0 else 0,
            'similarity_median': float(df_valid['最大相似度'].median()) if len(df_valid) > 0 else 0,
            'similarity_min': float(df_valid['最大相似度'].min()) if len(df_valid) > 0 else 0,
            'similarity_max': float(df_valid['最大相似度'].max()) if len(df_valid) > 0 else 0
        }
    
    if table11_df is not None:
        grade_counts = table11_df["政策等级"].value_counts()
        run_info['table11_sampled'] = {
            'total_policies': len(table11_df),
            'central_count': len(table11_df[table11_df["类型"] == "中央"]),
            'local_count': len(table11_df[table11_df["类型"] == "地方"]),
            'grade_distribution': grade_counts.to_dict(),
            'highest_pmc': float(table11_df["PMC得分"].max()),
            'lowest_pmc': float(table11_df["PMC得分"].min()),
            'local_mean_pmc': float(table11_df[table11_df["类型"] == "地方"]["PMC得分"].mean()) if len(table11_df[table11_df["类型"] == "地方"]) > 0 else None,
            'grade_standard': 'Tab.10 (优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0)',
            'sort_order': 'PMC得分降序（从高到低）'
        }
    
    if surface_files:
        run_info['pmc_surface_charts']['files'] = list(surface_files.keys())
    
    if barplot_files:
        run_info['province_topic_visualization']['barplot_files'] = list(barplot_files.keys())
    
    if province_doc_topic_df is not None:
        run_info['province_topic_visualization']['province_doc_topic_count'] = len(province_doc_topic_df)
        run_info['province_topic_visualization']['topic_distribution'] = province_doc_topic_df['主题'].value_counts().to_dict()
        run_info['province_topic_visualization']['province_distribution'] = province_doc_topic_df['地区'].value_counts().to_dict()
    
    if central_doc_topic_df is not None:
        run_info['province_topic_visualization']['central_doc_topic_count'] = len(central_doc_topic_df)
        run_info['province_topic_visualization']['central_topic_distribution'] = central_doc_topic_df['主题'].value_counts().to_dict()
    
    # ==================== 【修复】确保 run_info_path 被正确定义 ====================
    run_info_path = os.path.join(OUTPUT_DIR, 'run_info.json')
    with open(run_info_path, 'w', encoding='utf-8') as f:
        json.dump(run_info, f, indent=2, ensure_ascii=False)
    print(f"\n✅ Run information saved to: {run_info_path}")

# ==================== 主程序 ====================

def main():
    """主程序：分层抽样（层一保留全部等级 + 层二等级修补）"""

    MATCH_MODE = 'doc_ratio'
    MATCH_THRESHOLD = 0.55

    print("=" * 100)
    print("Youth Sports Policy Comprehensive Analysis System")
    print("(Final Fixed Edition + Table 5, Table 6 & Table 7 + PMC Indicators + Stratified Sampling + Table 11 + PMC Surface Charts + Province Topic Visualization)")
    print("")
    print("  ⚠️  WEIGHT SCHEME: EQUAL WEIGHTS (Delphi method removed)")
    print(f"     Each indicator weight = 1/{len(PRIMARY_KEYS)} = {1.0/len(PRIMARY_KEYS):.4f} ({1.0/len(PRIMARY_KEYS)*100:.1f}%)")
    print("")
    print("  📊 PMC SCORING METHOD: 分段评分法-平衡版")
    print("     - 命中率 ≥ 80% → 1.00 分（满分）")
    print("     - 命中率 ≥ 60% → 0.80 分")
    print("     - 命中率 ≥ 40% → 0.60 分")
    print("     - 命中率 ≥ 20% → 0.40 分")
    print("     - 命中率 > 0%  → 0.25 分")
    print("     - 命中率 = 0%  → 0.00 分")
    print("")
    print("  📋 GRADE STANDARD: Tab.10")
    print("     - 优秀: PMC ≥ 7.0")
    print("     - 良好: PMC ≥ 6.0")
    print("     - 可接受: PMC ≥ 5.0")
    print("     - 不良: PMC < 5.0")
    print("")
    print("  📋 TABLE 11: 按PMC得分降序排序（从高到低）")
    print("")
    print("  📊 PMC SURFACE CHARTS: 基于真实政策数据的3D可视化")
    print("     - 选取标准：等级覆盖 + 极值对比 + 层级与地域多样性 + 维度得分结构差异")
    print("     - 合并图：自动选取4个地方地区（基于等级和区域多样性）")
    print("     - 单图：显示5个地区（包括中央）")
    print("     - PMC得分计算：Σ(X1-X9) / 9 × 10（与表11一致）")
    print("     - 【修改】横纵坐标已互换（矩阵转置）")
    print("")
    print("  📊 31 PROVINCES TOPIC VISUALIZATION: 基于真实LDA模型输出")
    print("     - 发文数与主题数分组柱状图：左柱状为发文数，右柱状为主题数")
    print("     - 主题数采用硬聚类：每个文档只分配1个主题")
    print("     - 各省份主题分布统计：各省份在各LDA主题上的文档数")
    print("     - 中央政策文档-主题分布表：中央政策文档的主题分配")
    print("")
    print("  📌 NOTE: X10 (央地一致性) 已删除，共9个一级指标，34个二级指标")
    print("")
    print("  📰 PEOPLE'S DAILY CORPUS: 采样数量 = {} 篇文章".format(PEOPLE_DAILY_CONFIG['max_articles']))
    print("")
    print("  🔒 DOC2VEC TABLE 7: 可复现模式已启用 (workers=1, 所有随机种子固定)")
    print("")
    print("  🎯 STRATIFIED SAMPLING: 层一（排除不良 + 时期/区域双层约束）")
    print("")
    print("Module 0: Stratified Sampling (Regional Ratio 1:2:2:3, Periods: 十二五/十三五/十四五, 保留全部等级)")
    print("Module 1: LDA Topic Model (Perplexity) + Doc2Vec Text Similarity")
    print("Module 2: PMC Index Evaluation System (分段评分法-平衡版 + Equal Weights + People's Daily Corpus)")
    print("Module 3: Central-Local Policy Theme Inheritance, Diffusion, and Synergy (Table 5 & Table 6)")
    print("Module 4: Central-Local Policy Text Similarity (Table 7 - Doc2Vec)")
    print("Module 5: Table 11 - PMC Score Table (Only 9 sampled policies, sorted by PMC descending)")
    print("Module 6: PMC Surface Charts (Based on real policy data, 3D visualization)")
    print("Module 7: Province Topic Visualization (Hard Clustering)")
    print(f"Doc2Vec Parameters: dm={DOC2VEC_PARAMS['dm']}, window={DOC2VEC_PARAMS['window']}, ")
    print(f"                    min_count={DOC2VEC_PARAMS['min_count']}, size={DOC2VEC_PARAMS['vector_size']}, workers={DOC2VEC_PARAMS['workers']}")
    print(f"Match Mode: {MATCH_MODE}")
    print(f"Match Threshold: {MATCH_THRESHOLD}")
    print(f"Random seed: {RANDOM_SEED}")
    print("=" * 100)

    print(f"\nData Paths:")
    print(f"  Central Policy: {CENTRAL_PATH}")
    print(f"  Local Policy: {LOCAL_PATH}")
    print(f"  People's Daily Corpus: {RMRB_PATH}")
    print(f"  Output Directory: {OUTPUT_DIR}")

    print("\nLoading stopwords...")
    stopwords = load_stopwords()
    print(f"Loaded {len(stopwords)} stopwords")
 # ==================== 【调试】检查 179 是否在地方映射表里 ====================
    print("\n" + "=" * 60)
    print("【调试】检查 179-2025-Hunan.txt 映射")
    print("=" * 60)
    print("179 in LOCAL mapping:", "179-2025-Hunan.txt" in NEW_TO_OLD_FILE_LOCAL)
    print("179 value:", NEW_TO_OLD_FILE_LOCAL.get("179-2025-Hunan.txt", "<MISSING>"))
    print("LOCAL mapping 总条数:", len(NEW_TO_OLD_FILE_LOCAL))
    print("=" * 60)
    # ==================== 【调试结束】 ====================
    # ================================================================
    # 【层一关键改动】PRE-STEP：先把 PMC 所需的 docs / secondary / weights
    #                   准备好，再进入抽样模块
    # ================================================================
    print("\n" + "=" * 100)
    print("PRE-STEP: 读取全量政策 + 计算二级指标 + 权重（供抽样预计算PMC用）")
    print("=" * 100)

    docs, names = read_all_policies()
    if not docs:
        print("[X] Error: No policy files found")
        return

    policy_words = extract_policy_keywords(docs, stopwords, top_n=300)

    print("\n📁 Loading People's Daily corpus...")
    print(f"   📊 Target articles: {PEOPLE_DAILY_CONFIG['max_articles']}")
    rmrb = PeopleDailyCorpus(RMRB_PATH)
    external_words = rmrb.get_keywords(stopwords)

    if len(external_words) > 0:
        print(f"   [OK] People's Daily corpus loaded: "
              f"{len(external_words)} high-frequency words "
              f"from {PEOPLE_DAILY_CONFIG['max_articles']} articles")
    else:
        print(f"   [!] People's Daily corpus not loaded")

    config = get_secondary_config()
    df_logic, secondary = calculate_match_rates(config, policy_words, external_words)
    df_logic.to_excel(os.path.join(OUTPUT_DIR, "二级指标配置表.xlsx"), index=False)
    print(f"\n   [OK] Secondary indicator config table saved")

    print("\n📋 Using EQUAL WEIGHTS (9 indicators)...")
    weight_provider = EqualWeightProvider()
    weights_df = weight_provider.get_weights_dataframe()
    delphi_stats_df = weight_provider.get_statistics()
    consensus_report = weight_provider.get_consensus_report()
    expert_count = weight_provider.get_expert_count()
    weights_df.to_csv(
        os.path.join(OUTPUT_DIR, "PMC_等权重表.csv"),
        index=False, encoding='utf-8-sig'
    )
    print(f"   [OK] Equal weights saved")
    print(consensus_report)
    weights = weight_provider.get_weights()

    # ================================================================
    # 模块零：分层抽样（层一：传入 secondary / weights 保留全部等级，含不良）
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 0: Stratified Sampling (层一：保留全部等级，含不良)")
    print("=" * 100)

    sampled_local, full_local_df, central_selected = run_stratified_sampling(
        central_path=CENTRAL_PATH,
        local_path=LOCAL_PATH,
        total_sample=STRATIFIED_SAMPLE_CONFIG['total_sample'],
        region_ratio=STRATIFIED_SAMPLE_CONFIG['region_ratio'],
        periods=[],                     # ← 关键：关闭三时期强制覆盖
        secondary=secondary,
        weights=weights
    )



    
    # ================================================================
    # 输出PMC指标体系
    # ================================================================
    print("\n" + "=" * 100)
    print("PMC Indicator System Output (9 Primary Indicators, 34 Secondary Indicators)")
    print("=" * 100)

    pmc_indicator_df = get_pmc_indicator_system()
    pmc_indicator_df.to_csv(
        os.path.join(OUTPUT_DIR, "PMC_指标体系_完整表.csv"),
        index=False, encoding='utf-8-sig'
    )
    try:
        pmc_indicator_df.to_excel(
            os.path.join(OUTPUT_DIR, "PMC_指标体系_完整表.xlsx"),
            index=False
        )
        print(f"   [OK] PMC indicator system saved (Excel)")
    except Exception as e:
        print(f"   [!] Excel export failed: {e}")
    print(f"   [OK] PMC indicator system saved (CSV)")
    print(f"\nPMC Indicator System Summary:")
    print(f"   Total primary indicators: {len(PRIMARY_KEYS)}")
    print(f"   Total secondary indicators: {len(pmc_indicator_df)}")
    print(f"   Columns: {', '.join(pmc_indicator_df.columns.tolist())}")

    # ================================================================
    # 模块一：LDA + Doc2Vec（句子级）
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 1: LDA Topic Model (Perplexity) + Doc2Vec Text Similarity")
    print("=" * 100)

    central_docs, central_files = read_text_files(CENTRAL_PATH, "中央政策")
    local_docs, local_files = read_text_files(LOCAL_PATH, "地方政策")

    central_lda_results = None
    local_lda_results = None

    if central_docs:
        central_lda_results = analyze_topics_with_perplexity(central_docs, "中央政策", stopwords)

    if local_docs:
        local_lda_results = analyze_topics_with_perplexity(local_docs, "地方政策", stopwords)

    if central_lda_results and local_lda_results:
        plot_combined_perplexity_curves(central_lda_results, local_lda_results)

    topic_similarity_df = None

    print("\n" + "=" * 80)
    print("MODULE 1 (Continued): Doc2Vec Text Similarity Analysis (Sentence-level)")
    print("=" * 80)

    central_sentences, central_count = read_policy_to_sentences(CENTRAL_PATH, 'central', stopwords)
    local_sentences, local_count = read_policy_to_sentences(LOCAL_PATH, 'local', stopwords)

    similarity_stats = None
    if central_sentences and local_sentences:
        model, vectors, documents = train_doc2vec_model(
            central_sentences + local_sentences,
            vector_size=100,
            epochs=20
        )
        similarity_stats = calculate_similarity_with_random_sampling(
            central_sentences, local_sentences, vectors, max_samples=5000
        )

    # ================================================================
    # 模块五：表7 - 央地政策文本相似度（文档级 Doc2Vec）
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 5: Table 7 - Central-Local Policy Text Similarity (Document-level Doc2Vec)")
    print("=" * 100)

    table7_df = None

    if central_docs and local_docs:
        print("\n[Step 1] Reading policies for Table 7 Doc2Vec...")
        central_words, central_files, central_provinces = read_policies_for_doc2vec(CENTRAL_PATH, stopwords)
        local_words, local_files, local_provinces = read_policies_for_doc2vec(LOCAL_PATH, stopwords)

        if len(central_words) > 0 and len(local_words) > 0:
            all_words = central_words + local_words
            # 【修改】用旧文件名作为 ID，保证与旧代码一致
            central_ids_old = [f"中央_{NEW_TO_OLD_FILE_CENTRAL.get(f, f)}" for f in central_files]
            local_ids_old = [f"地方_{NEW_TO_OLD_FILE_LOCAL.get(f, f)}" for f in local_files]
            all_ids = central_ids_old + local_ids_old
            local_ids = local_ids_old
            central_ids = central_ids_old



            print(f"\n[Step 2] Training Doc2Vec model for Table 7...")
            print(f"  Total documents: {len(all_words)}")
            print(f"  Central: {len(central_words)}")
            print(f"  Local: {len(local_words)}")

            model_table7 = train_doc2vec_for_table7(all_words, all_ids)

            print("\n[Step 3] Calculating similarity scores...")
            table7_df = calculate_central_local_similarity_table7(
                model_table7, central_words, central_ids, local_words, local_ids, local_provinces
            )

            if table7_df is not None and len(table7_df) > 0:
                save_table7_results(table7_df, OUTPUT_DIR)

                print("\n" + "=" * 80)
                print("表7 各省青少年体育政策央地文本相似度（31个省份）")
                print("=" * 80)
                print(table7_df[['省份', '政策数', '最大相似度', '平均相似度']].to_string(index=False))
                print("=" * 80)

    # ================================================================
    # 模块三：表5 - 主题承继比、扩散比、协同度
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 3: Table 5 - Central-Local Policy Theme Inheritance, Diffusion, and Synergy")
    print("=" * 100)

    table5_df = None
    central_themes = None

    if central_docs and local_docs and local_files:
        table5_df, central_themes = calculate_hscope_dscope_tr(
            central_documents=central_docs,
            local_documents=local_docs,
            local_file_names=local_files,
            stopwords=stopwords,
            top_n=15,
            match_threshold=MATCH_THRESHOLD,
            match_mode=MATCH_MODE
        )

        if table5_df is not None and len(table5_df) > 0:
            table5_simple = save_table5_results(table5_df, OUTPUT_DIR)

            print("\n" + "=" * 80)
            print(f"表5 各省主题承继比、扩散比、协同度结果 (模式={MATCH_MODE}, 阈值={MATCH_THRESHOLD})")
            print("=" * 80)
            print(table5_df[['地区', '主题承继比(Hscope)', '主题扩散比(Dscope)', '主题协同度(TR)']].to_string(index=False))
            print("=" * 80)

    # ================================================================
    # 模块四：表6 - 各地区汇总
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 4: Table 6 - Regional Summary Analysis")
    print("=" * 100)

    table6_df = None

    if table5_df is not None and len(table5_df) > 0:
        table6_df = calculate_region_summary(table5_df)

        if table6_df is not None and len(table6_df) > 0:
            save_table6_results(table6_df, OUTPUT_DIR)

    # ================================================================
    # 模块二：PMC 指数评价
    # 【层一】docs / names / secondary / weights 已在 PRE-STEP 准备好，
    #         此处不再重复 read_all_policies / calculate_match_rates / EqualWeightProvider
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 2: PMC Index Evaluation System (分段评分法-平衡版, 9 indicators)")
    print("=" * 100)

    df_scores = batch_calc_pmc_scores(docs, names, secondary, weights)
    df_scores.to_csv(
        os.path.join(OUTPUT_DIR, "政策PMC得分表_分段评分法.csv"),
        index=False, encoding='utf-8-sig'
    )
    print(f"   [OK] PMC scores saved")

    score_stats = analyze_scores_with_bootstrap(df_scores, n_bootstrap=1000)
    cluster_res = clustering_validation_pmc(docs, secondary)

    print("\n📊 Calculating primary indicator scores...")
    central_docs_pmc = [docs[i] for i, name in enumerate(names) if name.startswith('中央')]
    local_docs_pmc = [docs[i] for i, name in enumerate(names) if name.startswith('地方')]

    central_primary_df = calculate_primary_scores_for_visualization(central_docs_pmc, secondary, weights)
    local_primary_df = calculate_primary_scores_for_visualization(local_docs_pmc, secondary, weights)

    if len(external_words) > 0:
        keywords_df = pd.DataFrame(list(external_words), columns=["关键词"])
        keywords_df.to_csv(
            os.path.join(OUTPUT_DIR, "人民日报_高频关键词.csv"),
            index=False, encoding='utf-8-sig'
        )
        print(f"   [OK] People's Daily keywords saved")

    print("\n📊 中央-地方政策对比分析...")

    central_means = central_primary_df.mean(axis=1)
    local_means = local_primary_df.mean(axis=1)
    central_mean = central_means.mean()
    central_std = central_means.std()
    local_mean = local_means.mean()
    local_std = local_means.std()

    print(f"   [OK] 中央政策均值: {central_mean:.2f}, 标准差: {central_std:.2f}")
    print(f"   [OK] 地方政策均值: {local_mean:.2f}, 标准差: {local_std:.2f}")

    # ================================================================
    # 模块五：表11
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 5: Table 11 - PMC Score Table (Only 9 Sampled Policies: 1 Central + 8 Local)")
    print("评分方法：分段评分法-平衡版")
    print("等级标准：Tab.10（优秀≥7.0, 良好≥6.0, 可接受≥5.0, 不良<5.0）")
    print("排序方式：按PMC得分降序排序（从高到低）")
    print("抽样方案：层一（排除不良 + 时期/区域双层约束）")
    print("=" * 100)

    table11_df = None

    if len(sampled_local) > 0 and not central_selected.empty:
        # ================================================================
        # 【复现原代码】层二等级修补：关闭
        #   - 不再做任何等级替换
        #   - 保留 旧文件名称 / 排序键 回填，避免 CSV 出现空值
        #   - 保存抽样结果（内容=层一结果）
        # ================================================================
        print("\n" + "=" * 100)
        print("PRE-TABLE11: 复现原代码模式，跳过层二等级修补")
        print("=" * 100)

        patch_log = []

        # ---------- 【兜底】回填 旧文件名称 / 排序键 ----------
        sampled_local['旧文件名称'] = sampled_local['文件名称'].map(
            lambda x: NEW_TO_OLD_FILE_LOCAL.get(x, '')
        )
        sampled_local['排序键'] = sampled_local['文件名称'].map(
            lambda x: NEW_TO_OLD_FILE_LOCAL.get(x, x)
        )

        # ---------- 明确 drop 掉修补列，保证输出干净 ----------
        sampled_local = sampled_local.drop(
            columns=['_PMC', '_等级', '代表性评分', '_region_full'],
            errors='ignore'
        )

        # ---------- 保存抽样结果 ----------
        save_local = sampled_local.copy()
        save_local.to_csv(
            os.path.join(OUTPUT_DIR, '省级政策抽样结果.csv'),
            index=False, encoding='utf-8-sig'
        )
        print(f"   [OK] 抽样结果已保存（复现原代码模式）")

        # ---------- 无修补日志 ----------
        print(f"   [--] 无等级修补，跳过修补日志")

        # ---------- 生成表11 ----------
        table11_df = generate_pmc_score_table_sampled_only(
            sampled_local=sampled_local,
            central_selected=central_selected,
            secondary=secondary,
            weights=weights,
            output_dir=OUTPUT_DIR
        )

        # ---------- 三时期覆盖情况（只展示，不兜底） ----------
        if table11_df is not None and len(table11_df) > 0:
            local_in_table = table11_df[table11_df['类型'] == '地方']
            present = set(local_in_table['所属时期'].unique())
            required = ['十二五', '十三五', '十四五']

            print(f"\n   【表11 三时期覆盖情况】")
            for p in required:
                cnt = len(local_in_table[local_in_table['所属时期'] == p])
                status = "[OK]" if cnt > 0 else "[--]"
                print(f"      {status} {p}: {cnt} 份")

            missing = [p for p in required if p not in present]
            if missing:
                print(f"\n   [i] 表11 缺失时期: {missing}（复现原代码模式，不做兜底）")
            else:
                print(f"\n   [OK] 表11 三时期全覆盖")
    else:
        print("   [!] 分层抽样数据不完整，无法生成表11") 


    # ================================================================
    # 模块六：PMC曲面图
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 6: PMC Surface Charts (Based on Real Policy Data)")
    print("=" * 100)

    surface_files = {}
    if table11_df is not None and len(table11_df) > 0:
        surface_files = generate_pmc_surface_charts(
            table11_df=table11_df,
            output_dir=OUTPUT_DIR,
            selected_regions=None
        )

        if surface_files:
            print(f"\n   [OK] 共生成 {len(surface_files)} 个PMC曲面图文件")
            print(f"      - 合并图（4个地方地区）: {surface_files.get('combined', '未生成')}")
            single_count = len([k for k in surface_files.keys() if k.startswith('single_')])
            print(f"      - 单图（5个地区）: {single_count} 个")
    else:
        print("   [!] 表11数据为空，跳过PMC曲面图生成")

    # ================================================================
    # 模块七：31省份发文数与主题数分组柱状图
    # ================================================================
    print("\n" + "=" * 100)
    print("MODULE 7: 31省份政策发文数与主题数分布分组柱状图")
    print("主题数采用硬聚类：每个文档只分配1个主题")
    print("=" * 100)

    barplot_files = {}
    if local_lda_results is not None and len(local_docs) > 0:
        barplot_files = generate_province_doc_topic_barplot(
            local_lda_results=local_lda_results,
            local_docs=local_docs,
            local_files=local_files,
            output_dir=OUTPUT_DIR
        )
    else:
        print("   [!] 地方LDA结果或文档为空，跳过分组柱状图生成")

    # ================================================================
    # 各省份政策文档-主题分布表（硬聚类）
    # ================================================================
    print("\n" + "=" * 100)
    print("生成各省份政策文档-主题分布表（硬聚类）")
    print("每份文档只分配给概率最高的1个主题")
    print("=" * 100)

    province_doc_topic_df = None
    if local_lda_results is not None and len(local_docs) > 0:
        province_doc_topic_df = generate_province_document_topic_table_hard_clustering(
            local_lda_results=local_lda_results,
            local_docs=local_docs,
            local_files=local_files,
            output_dir=OUTPUT_DIR
        )
    else:
        print("   [!] 地方LDA结果或文档为空，跳过文档-主题分布表生成")

    # ================================================================
    # 中央政策文档-主题分布表
    # ================================================================
    print("\n" + "=" * 100)
    print("生成中央政策文档-主题分布表（硬聚类）")
    print("=" * 100)

    central_doc_topic_df = None
    if central_lda_results is not None and len(central_docs) > 0:
        central_doc_topic_df = generate_central_document_topic_table(
            central_lda_results=central_lda_results,
            central_docs=central_docs,
            central_files=central_files,
            output_dir=OUTPUT_DIR
        )
    else:
        print("   [!] 中央LDA结果或文档为空，跳过中央文档-主题分布表生成")

    # ================================================================
    # 生成综合报告
    # ================================================================
    print("\n" + "=" * 80)
    print("Generating Complete Chinese Analysis Report")
    print("=" * 80)

    generate_complete_chinese_report(
        central_lda_results, local_lda_results,
        similarity_stats, topic_similarity_df,
        score_stats, weights_df, cluster_res,
        delphi_stats_df, expert_count,
        central_mean, local_mean, central_std, local_std,
        table5_df,
        table6_df,
        table7_df,
        pmc_indicator_df,
        MATCH_THRESHOLD,
        MATCH_MODE,
        sampled_local,
        central_selected,
        table11_df,
        surface_files,
        barplot_files,
        province_doc_topic_df,
        central_doc_topic_df
    )

    save_run_info(
        score_stats, similarity_stats, central_lda_results, local_lda_results,
        table5_df, table6_df, table7_df, MATCH_THRESHOLD, MATCH_MODE,
        sampled_local, central_selected, table11_df, surface_files,
        barplot_files, province_doc_topic_df, central_doc_topic_df
    )

    print("\n" + "=" * 90)
    print("[OK] ALL ANALYSIS COMPLETED!")
    print(f"📁 All results saved to: {OUTPUT_DIR}")
    print("=" * 90)

    print("\n📁 OUTPUT FILES SUMMARY:")
    print("   [OK] 省级政策抽样结果.csv / 中央政策抽样结果.csv")
    print("   [OK] PMC_指标体系_完整表.csv / .xlsx")
    print("   [OK] 政策PMC得分表_分段评分法.csv")
    print("   [OK] 表11_分层抽样政策PMC指数得分表_分段评分法_Tab10等级_按PMC排序.csv / .xlsx")
    print("   [OK] 表5_各省主题承继比_扩散比_协同度.csv / .xlsx")
    print("   [OK] 表6_各地区青少年体育政策主题承继比_扩散比_协同度结果.csv / .xlsx")
    print("   [OK] 表7_各省青少年体育政策央地文本相似度.csv / .xlsx")

    if surface_files:
        print(f"   [OK] PMC曲面图_地方四合一_真实数据.png (只显示4个地方地区)")
        single_count = len([k for k in surface_files.keys() if k.startswith('single_')])
        print(f"   [OK] PMC曲面图_*_真实数据.png ({single_count}个独立曲面图，包括中央)")
    else:
        print("   [!] PMC曲面图：未生成")

    print("   [OK] 31省份政策发文数与主题数分布_分组柱状图.png")
    print("   [OK] 各省份主题分布统计_硬聚类.csv")
    print("   [OK] 中央政策文档-主题分布表_硬聚类.csv")
    print("   [OK] 31省份发文数与主题数_硬聚类.csv")
    print("   [OK] 青少年体育政策综合分析报告.txt")
    print("   [OK] run_info.json")
    print("")
    print("   📌 抽样与表11 特性：")
    print("      - 层一：保留全部等级（含不良），时期+区域双层约束")
    print("      - 层二：等级修补（必覆盖 优秀/良好/可接受/不良）")
    print("      - 表11：1 份中央 + 8 份地方，按 PMC 降序排列")
    print("      - 表11 三时期强制覆盖（十二五/十三五/十四五）")
    print("      - 曲面图：从表11 中每区域各取 1 个（东北/东部/中部/西部 + 中央）")
    print("=" * 90)


if __name__ == "__main__":
    main()